# PantryChef implementation status

## Feature 1 — Pantry management
Status: **BLOCKED — backend/API checks pass; frontend browser acceptance remains unverified**

### Implemented
- [x] FastAPI CRUD endpoints for pantry items
- [x] SQLAlchemy models for ingredients and pantry items
- [x] Validation for positive quantities, supported units, names and dates
- [x] Reject explicit null for required PATCH fields and reject empty PATCH payloads
- [x] Next.js pantry management screen (add/edit/delete/list/search)
- [x] Mutation flow distinguishes a successful save from a failed list refresh
- [x] PostgreSQL Docker Compose configuration

### Verification evidence
- [x] Backend pytest suite passes (see current total below)
- [x] Live FastAPI smoke test against a persistent SQLite database — create, edit, invalid quantity rejection, list and delete passed in prior verification
- [x] API process restart preserved a previously stored SQLite row in prior verification
- [ ] PostgreSQL container start and direct persistence verification (Docker and PostgreSQL server binaries are not installed in this runtime)
- [ ] Frontend dependency installation and production build (blocked: npm registry DNS lookup fails with `EAI_AGAIN registry.npmjs.org`; npm cache is empty)
- [ ] Open actual Next.js page in browser and interact with controls (blocked: dependencies cannot be installed; Chromium navigation to local pages is rejected by runtime policy)
- [ ] Verify browser refresh preserves rows via live API
- [ ] Verify UI behavior during API outage

Do not mark Feature 1 PASS until frontend build/browser acceptance and PostgreSQL verification pass.

## Feature 2 — Recipe suggestions from pantry
Status: **IMPLEMENTED — API tested; frontend/database acceptance incomplete**

### Implemented
- [x] Added `Recipe` and `RecipeIngredient` SQLAlchemy models
- [x] Added an idempotently seeded catalogue of 20 curated Vietnamese recipes
- [x] Added `GET /api/recipes/suggestions` with `min_fit` and `limit` validation
- [x] Match real pantry records to recipe requirements using normalized Vietnamese names and a small explicit alias map
- [x] Quantity matching for exact units and conversions between g/kg and ml/l
- [x] Show available/required amounts, missing ingredient amounts, match count, fit score and instructions
- [x] Exclude expired pantry lots from usable quantity; prioritize recipes with sufficiently available ingredients expiring within three days
- [x] Added `/recipes` Next.js screen with all/ready/near-expiry filters and expandable cooking steps
- [x] Added link from pantry page to recipe suggestions

### Verification evidence
- [x] Backend suite: **52 passed** (including 20 parametrized quantity/name scenarios)
- [x] `python -m compileall -q app` passed
- [x] Live Uvicorn smoke test with isolated SQLite database: `/health` returned 200; endpoint returned 20 recipes; after adding 2 eggs expiring soon, the boiled-egg recipe scored 100 and was flagged for near-expiry priority
- [x] Empty pantry returns the finite catalogue with zero fit; suggestions are only stored catalogue recipes
- [ ] PostgreSQL recipe seed and matching verification
- [ ] Frontend dependencies/build (blocked by npm DNS)
- [ ] Browser click-through on the actual Next.js page
- [ ] End-to-end acceptance across 20 scenarios using the deployed frontend and PostgreSQL

## Gate decision
Feature 2's backend implementation is in place, but neither Feature 1 nor Feature 2 is fully accepted. Do not claim complete product acceptance until the blocked environment checks have been performed. Feature 3 (guided cooking and exact stock deduction) has not started.
