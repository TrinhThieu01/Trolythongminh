from datetime import date, datetime
from decimal import Decimal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

ALLOWED_UNITS = {"g", "kg", "ml", "l", "quả", "củ", "bó", "gói", "miếng", "thìa", "chai", "ổ"}

class IngredientOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    category: str | None
    default_unit: str

class PantryCreate(BaseModel):
    ingredient_name: str = Field(min_length=1, max_length=150)
    category: str | None = Field(default=None, max_length=80)
    quantity: Decimal = Field(gt=0, max_digits=12, decimal_places=3)
    unit: str = Field(min_length=1, max_length=20)
    expiry_date: date | None = None

    @field_validator("ingredient_name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        value = " ".join(value.split())
        if not value:
            raise ValueError("Tên nguyên liệu không được để trống")
        return value

    @field_validator("unit")
    @classmethod
    def clean_unit(cls, value: str) -> str:
        value = value.strip()
        if value not in ALLOWED_UNITS:
            raise ValueError("Đơn vị chưa được hỗ trợ")
        return value

class PantryUpdate(BaseModel):
    quantity: Decimal | None = Field(default=None, gt=0, max_digits=12, decimal_places=3)
    unit: str | None = Field(default=None, min_length=1, max_length=20)
    expiry_date: date | None = None

    @field_validator("unit")
    @classmethod
    def clean_unit(cls, value: str | None) -> str | None:
        if value is not None and value.strip() not in ALLOWED_UNITS:
            raise ValueError("Đơn vị chưa được hỗ trợ")
        return value.strip() if value else value

    @model_validator(mode="after")
    def reject_null_required_fields(self):
        if "quantity" in self.model_fields_set and self.quantity is None:
            raise ValueError("Số lượng không được để trống")
        if "unit" in self.model_fields_set and self.unit is None:
            raise ValueError("Đơn vị không được để trống")
        if not self.model_fields_set:
            raise ValueError("Cần cung cấp ít nhất một trường để cập nhật")
        return self

class PantryOut(BaseModel):
    id: int
    ingredient_id: int
    ingredient_name: str
    category: str | None
    quantity: Decimal
    unit: str
    expiry_date: date | None
    updated_at: datetime | None
