from contextlib import asynccontextmanager
from datetime import date
from decimal import Decimal
import os

from fastapi import Depends, FastAPI, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from .database import Base, engine, get_db
from .models import Ingredient, PantryItem, Recipe
from .recipe_catalog import seed_recipes
from .schemas import IngredientOut, PantryCreate, PantryOut, PantryUpdate

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    from .database import SessionLocal
    with SessionLocal() as db:
        seed_recipes(db)
    yield

app = FastAPI(title="PantryChef API", version="0.1.0", lifespan=lifespan)
origins = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in origins],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def to_pantry_out(item: PantryItem) -> PantryOut:
    return PantryOut(
        id=item.id,
        ingredient_id=item.ingredient_id,
        ingredient_name=item.ingredient.name,
        category=item.ingredient.category,
        quantity=item.quantity,
        unit=item.unit,
        expiry_date=item.expiry_date,
        updated_at=item.updated_at,
    )

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/api/ingredients", response_model=list[IngredientOut])
def list_ingredients(db: Session = Depends(get_db)):
    return list(db.scalars(select(Ingredient).order_by(Ingredient.name)).all())

@app.get("/api/pantry", response_model=list[PantryOut])
def list_pantry(
    search: str | None = Query(default=None, max_length=100),
    db: Session = Depends(get_db),
):
    stmt = select(PantryItem).options(joinedload(PantryItem.ingredient)).order_by(PantryItem.id.desc())
    items = list(db.scalars(stmt).unique().all())
    if search:
        needle = search.casefold().strip()
        items = [item for item in items if needle in item.ingredient.name.casefold()]
    return [to_pantry_out(item) for item in items]

@app.post("/api/pantry", response_model=PantryOut, status_code=201)
def create_pantry(payload: PantryCreate, db: Session = Depends(get_db)):
    name = payload.ingredient_name
    ingredient = db.scalar(select(Ingredient).where(Ingredient.name.ilike(name)))
    if ingredient is None:
        ingredient = Ingredient(
            name=name,
            category=payload.category,
            default_unit=payload.unit,
        )
        db.add(ingredient)
        try:
            db.flush()
        except IntegrityError:
            db.rollback()
            ingredient = db.scalar(select(Ingredient).where(Ingredient.name.ilike(name)))
            if ingredient is None:
                raise HTTPException(status_code=409, detail="Nguyên liệu đã tồn tại; vui lòng thử lại")
    elif payload.category and not ingredient.category:
        ingredient.category = payload.category

    item = PantryItem(
        ingredient=ingredient,
        quantity=payload.quantity,
        unit=payload.unit,
        expiry_date=payload.expiry_date,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return to_pantry_out(item)

@app.patch("/api/pantry/{item_id}", response_model=PantryOut)
def update_pantry(item_id: int, payload: PantryUpdate, db: Session = Depends(get_db)):
    item = db.scalar(
        select(PantryItem).options(joinedload(PantryItem.ingredient)).where(PantryItem.id == item_id)
    )
    if item is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy nguyên liệu trong kho")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(item, field, value)
    db.commit()
    db.refresh(item)
    return to_pantry_out(item)

@app.delete("/api/pantry/{item_id}", status_code=204)
def delete_pantry(item_id: int, db: Session = Depends(get_db)):
    item = db.get(PantryItem, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy nguyên liệu trong kho")
    db.delete(item)
    db.commit()
    return Response(status_code=204)


# Matching rules are deliberately deterministic: the app only recommends recipes
# stored in the curated database catalogue; it does not invent dish names.
import unicodedata

def normalize_food_name(value: str) -> str:
    text = unicodedata.normalize("NFD", value.casefold().strip())
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    text = text.replace("đ", "d")
    return " ".join(text.split())

ALIASES = {
    "trung ga": "trung", "trung vit": "trung", "ca chua bi": "ca chua",
    "dau hu": "dau phu", "rau muong bo": "rau muong",
    "hanh la": "hanh la", "hanh hoa": "hanh la", "thit lon": "thit heo",
    "thit ga ta": "thit ga", "dau an": "dau an",
}

def canonical_food(value: str) -> str:
    normalized = normalize_food_name(value)
    return ALIASES.get(normalized, normalized)

def convert_quantity(quantity: Decimal, source_unit: str, target_unit: str) -> Decimal | None:
    source_unit, target_unit = source_unit.strip().lower(), target_unit.strip().lower()
    if source_unit == target_unit:
        return quantity
    mass = {"g": Decimal("1"), "kg": Decimal("1000")}
    volume = {"ml": Decimal("1"), "l": Decimal("1000")}
    if source_unit in mass and target_unit in mass:
        return quantity * mass[source_unit] / mass[target_unit]
    if source_unit in volume and target_unit in volume:
        return quantity * volume[source_unit] / volume[target_unit]
    return None

def recipe_to_suggestion(recipe: Recipe, pantry_items: list[PantryItem], today: date) -> dict:
    ingredients = []
    missing = []
    matched_count = 0
    near_expiry_match = False
    for required in recipe.recipe_ingredients:
        target_name = canonical_food(required.ingredient_name)
        compatible_total = Decimal("0")
        found_any = False
        has_near_expiry = False
        for item in pantry_items:
            if canonical_food(item.ingredient.name) != target_name:
                continue
            if item.expiry_date is not None and item.expiry_date < today:
                continue
            converted = convert_quantity(Decimal(item.quantity), item.unit, required.unit)
            if converted is None:
                continue
            compatible_total += converted
            found_any = True
            if item.expiry_date is not None and 0 <= (item.expiry_date - today).days <= 3:
                has_near_expiry = True
        needed = Decimal(required.quantity)
        enough = found_any and compatible_total >= needed
        if enough:
            matched_count += 1
            near_expiry_match = near_expiry_match or has_near_expiry
        missing_amount = max(Decimal("0"), needed - compatible_total)
        detail = {
            "name": required.ingredient_name, "required_quantity": float(needed),
            "unit": required.unit, "available_quantity": float(compatible_total),
            "available": bool(enough), "near_expiry": bool(has_near_expiry and enough),
        }
        ingredients.append(detail)
        if not enough:
            missing.append({"name": required.ingredient_name, "quantity": float(missing_amount if found_any else needed), "unit": required.unit})
    base_score = round(100 * matched_count / len(recipe.recipe_ingredients)) if recipe.recipe_ingredients else 0
    score = min(100, base_score + (10 if near_expiry_match else 0))
    return {
        "id": recipe.id, "slug": recipe.slug, "name": recipe.name, "description": recipe.description,
        "minutes": recipe.minutes, "servings": recipe.servings, "instructions": recipe.instructions,
        "fit_score": score, "matched_ingredients": matched_count, "total_ingredients": len(recipe.recipe_ingredients),
        "near_expiry_priority": near_expiry_match, "ingredients": ingredients, "missing_ingredients": missing,
    }

@app.get("/api/recipes/suggestions")
def suggest_recipes(
    min_fit: int = Query(default=0, ge=0, le=100),
    limit: int = Query(default=20, ge=1, le=50),
    db: Session = Depends(get_db),
):
    pantry = list(db.scalars(select(PantryItem).options(joinedload(PantryItem.ingredient))).unique().all())
    recipes = list(db.scalars(select(Recipe).options(joinedload(Recipe.recipe_ingredients)).order_by(Recipe.id)).unique().all())
    today = date.today()
    suggestions = [recipe_to_suggestion(recipe, pantry, today) for recipe in recipes]
    suggestions = [item for item in suggestions if item["fit_score"] >= min_fit]
    suggestions.sort(key=lambda item: (item["near_expiry_priority"], item["fit_score"], item["matched_ingredients"]), reverse=True)
    return {"count": len(suggestions), "pantry_item_count": len(pantry), "suggestions": suggestions[:limit]}
