# PantryChef — MVP scaffold

PantryChef is a Vietnamese-language cooking assistant based on ingredients actually recorded in the pantry. The current codebase contains Feature 1 (pantry management) and an initial implementation of Feature 2 (recipe suggestions from the stored pantry and a curated database catalogue). Feature 1's browser/PostgreSQL acceptance remains blocked in the current runtime; Feature 2 must not be considered fully accepted until the frontend and database checks run in a supported environment.

## Stack
- Frontend: Next.js App Router, TypeScript, Tailwind CSS
- Backend: FastAPI, SQLAlchemy
- Database target: PostgreSQL via Docker Compose; SQLite was used only for local verification
- Tests: pytest

## Run
1. Copy `backend/.env.example` to `backend/.env` and set `DATABASE_URL` for your PostgreSQL instance.
2. From the project root run `docker compose up --build` in an environment with Docker available.
3. Pantry management: http://localhost:3000
4. Recipe suggestions: http://localhost:3000/recipes
5. Backend API docs: http://localhost:8000/docs
6. Backend health: http://localhost:8000/health

The frontend expects the API at `http://localhost:8000` by default. The recipe suggestion API is `GET /api/recipes/suggestions?min_fit=0&limit=20`. Recipes come only from the curated database catalogue; no recipe names are invented by a generative model. Ingredient matching checks normalized names, supported unit conversions (g/kg and ml/l), required quantities, expiry dates, missing ingredients, fit score and near-expiry priority. Expired pantry lots are not counted as usable stock.

The current execution environment cannot resolve `registry.npmjs.org` (`EAI_AGAIN`) and does not provide Docker/PostgreSQL. Consequently, Next.js production build, PostgreSQL persistence, and actual browser interaction remain unverified. See `docs/IMPLEMENTATION_STATUS.md` for the evidence and blockers. Do not claim browser acceptance based only on backend tests.

## Test backend
```bash
cd backend
python -m venv .venv
# activate the virtual environment, then:
pip install -r requirements.txt
pytest -q
```

## Feature 1 — Pantry management acceptance
- [ ] List, add, edit, search and delete pantry items in the real browser
- [x] Reject negative quantities and invalid inputs (API tests)
- [x] API CRUD and SQLite persistence across API restart (smoke test)
- [ ] Persist data in PostgreSQL
- [ ] Refresh page and verify data persists
- [ ] Verify empty state and API outage behavior in browser

## Feature 2 — Recipe suggestions acceptance
- [x] Curated database catalogue of 20 recipes, seeded idempotently
- [x] Match recipe ingredients to pantry entries using normalized names and aliases
- [x] Check quantities and supported g/kg, ml/l conversions
- [x] Show missing ingredient quantities and fit score
- [x] Ignore expired stock and prioritize recipes using sufficiently available near-expiry stock
- [x] 20 parametrized quantity/name matching scenarios, plus API integration tests
- [ ] Frontend build and actual browser click-through
- [ ] PostgreSQL recipe seed and suggestion verification
- [ ] Acceptance over 20 end-to-end pantry scenarios in the deployed stack
