"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

type RecipeIngredient = {
  name: string;
  required_quantity: number;
  unit: string;
  available_quantity: number;
  available: boolean;
  near_expiry: boolean;
};
type MissingIngredient = { name: string; quantity: number; unit: string };
type RecipeSuggestion = {
  id: number;
  slug: string;
  name: string;
  description: string;
  minutes: number;
  servings: number;
  instructions: string;
  fit_score: number;
  matched_ingredients: number;
  total_ingredients: number;
  near_expiry_priority: boolean;
  ingredients: RecipeIngredient[];
  missing_ingredients: MissingIngredient[];
};
type SuggestionResponse = { count: number; pantry_item_count: number; suggestions: RecipeSuggestion[] };
const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export default function RecipesPage() {
  const [data, setData] = useState<SuggestionResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<"all" | "ready" | "near">("all");
  const [expanded, setExpanded] = useState<number | null>(null);

  const loadSuggestions = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`${API}/api/recipes/suggestions?limit=50`, { cache: "no-store" });
      if (!response.ok) throw new Error("Chưa tải được gợi ý món ăn. Vui lòng thử lại.");
      setData(await response.json());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Không thể kết nối máy chủ.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadSuggestions(); }, [loadSuggestions]);

  const visible = useMemo(() => (data?.suggestions ?? []).filter((recipe) => {
    if (filter === "ready") return recipe.missing_ingredients.length === 0;
    if (filter === "near") return recipe.near_expiry_priority;
    return true;
  }), [data, filter]);

  return (
    <main className="min-h-screen">
      <header className="border-b border-[var(--line)] bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-4">
          <a href="/" className="flex items-center gap-3 no-underline">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--mint)] text-2xl">🥬</span>
            <span><span className="block text-xl font-bold tracking-tight">PantryChef</span><span className="block text-xs text-[var(--muted)]">Bếp gọn · Ăn ngon · Đỡ lãng phí</span></span>
          </a>
          <a href="/" className="rounded-full border border-[var(--line)] px-3 py-2 text-sm font-semibold text-[var(--green)] no-underline">← Kho nguyên liệu</a>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-5 py-8">
        <section className="mb-7 rounded-3xl bg-[#eaf2e8] p-6 sm:p-8">
          <p className="mb-2 text-sm font-bold uppercase tracking-widest text-[var(--green)]">GỢI Ý TỪ KHO THỰC TẾ</p>
          <h1 className="max-w-2xl text-3xl font-bold leading-tight sm:text-4xl">Hôm nay nấu món gì?</h1>
          <p className="mt-3 max-w-2xl leading-7 text-[#58695d]">Món ăn được chọn từ danh mục công thức đã lưu. PantryChef đối chiếu nguyên liệu và số lượng trong kho, hiển thị phần còn thiếu, đồng thời ưu tiên nguyên liệu sắp hết hạn.</p>
          <div className="mt-6 grid grid-cols-2 gap-3 sm:max-w-lg">
            <div className="rounded-2xl bg-white/80 p-4"><p className="text-sm text-[var(--muted)]">Nguyên liệu đang có</p><p className="mt-1 text-3xl font-bold">{data?.pantry_item_count ?? "—"}</p></div>
            <div className="rounded-2xl bg-white/80 p-4"><p className="text-sm text-[var(--muted)]">Công thức trong danh mục</p><p className="mt-1 text-3xl font-bold">{data?.count ?? "—"}</p></div>
          </div>
        </section>

        {error && <div role="alert" className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"><span>{error}</span><button onClick={() => void loadSuggestions()} className="font-bold underline">Thử lại</button></div>}

        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div><h2 className="text-xl font-bold">Món phù hợp với căn bếp</h2><p className="mt-1 text-sm text-[var(--muted)]">Điểm phù hợp dựa trên số lượng nguyên liệu đáp ứng được, không chỉ dựa vào tên.</p></div>
          <div className="flex flex-wrap gap-2" aria-label="Lọc món ăn">
            {([ ["all", "Tất cả"], ["ready", "Đủ nguyên liệu"], ["near", "Ưu tiên sắp hết hạn"] ] as const).map(([key, label]) => <button key={key} onClick={() => setFilter(key)} className={`rounded-full border px-3 py-2 text-sm font-semibold ${filter === key ? "border-[var(--green)] bg-[var(--green)] text-white" : "border-[var(--line)] bg-white text-[var(--ink)]"}`}>{label}</button>)}
          </div>
        </div>

        {loading ? <div className="rounded-2xl border border-[var(--line)] bg-white p-12 text-center text-[var(--muted)]">Đang đối chiếu công thức với kho nguyên liệu...</div>
          : visible.length === 0 ? <div className="rounded-2xl border border-dashed border-[var(--line)] bg-white px-6 py-14 text-center"><div className="text-4xl">🍲</div><h3 className="mt-3 font-bold">Chưa có món phù hợp với bộ lọc này</h3><p className="mt-2 text-sm text-[var(--muted)]">Hãy thêm nguyên liệu vào kho hoặc đổi bộ lọc.</p><a href="/" className="mt-4 inline-block font-semibold text-[var(--green)] underline">Cập nhật kho nguyên liệu</a></div>
          : <div className="grid gap-4 md:grid-cols-2">
            {visible.map((recipe) => <article key={recipe.id} className="rounded-2xl border border-[var(--line)] bg-white p-5 shadow-sm">
              <div className="flex items-start justify-between gap-4">
                <div><h3 className="text-lg font-bold">{recipe.name}</h3><p className="mt-1 text-sm leading-6 text-[var(--muted)]">{recipe.description}</p></div>
                <div className="min-w-16 rounded-xl bg-[var(--mint)] px-3 py-2 text-center"><p className="text-xl font-bold text-[var(--green)]">{recipe.fit_score}%</p><p className="text-[10px] font-semibold uppercase text-[var(--green)]">Phù hợp</p></div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold">
                <span className="rounded-full bg-gray-100 px-3 py-1.5">⏱ {recipe.minutes} phút</span>
                <span className="rounded-full bg-gray-100 px-3 py-1.5">🍽 {recipe.servings} phần</span>
                <span className="rounded-full bg-gray-100 px-3 py-1.5">{recipe.matched_ingredients}/{recipe.total_ingredients} nguyên liệu đủ</span>
                {recipe.near_expiry_priority && <span className="rounded-full bg-amber-100 px-3 py-1.5 text-amber-900">Ưu tiên dùng sớm</span>}
              </div>
              <div className="mt-4"><p className="text-sm font-bold">Cần chuẩn bị</p><div className="mt-2 flex flex-wrap gap-2">{recipe.ingredients.map((ingredient) => <span key={ingredient.name} className={`rounded-lg px-2.5 py-1.5 text-xs ${ingredient.available ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"}`}>{ingredient.available ? "✓" : "＋"} {ingredient.name} · {ingredient.required_quantity} {ingredient.unit}{ingredient.available && ingredient.near_expiry ? " · sắp hết hạn" : ""}</span>)}</div></div>
              {recipe.missing_ingredients.length > 0 && <p className="mt-3 text-sm text-[var(--muted)]"><span className="font-semibold text-red-700">Còn thiếu: </span>{recipe.missing_ingredients.map((item) => `${item.name} (${item.quantity} ${item.unit})`).join(", ")}</p>}
              <button onClick={() => setExpanded(expanded === recipe.id ? null : recipe.id)} aria-expanded={expanded === recipe.id} className="mt-4 w-full rounded-xl border border-[var(--line)] px-4 py-3 text-sm font-bold text-[var(--green)] hover:bg-[#f6faf5]">{expanded === recipe.id ? "Ẩn cách nấu" : "Xem cách nấu"}</button>
              {expanded === recipe.id && <div className="mt-4 rounded-xl bg-[#f7f8f5] p-4"><h4 className="font-bold">Cách thực hiện</h4><p className="mt-2 whitespace-pre-line text-sm leading-7">{recipe.instructions}</p><p className="mt-3 text-xs text-[var(--muted)]">Công thức tham khảo cho {recipe.servings} phần. Điều chỉnh gia vị theo khẩu vị và bảo đảm thịt, cá, trứng được nấu chín an toàn.</p></div>}
            </article>)}
          </div>}
        <footer className="mt-10 border-t border-[var(--line)] py-5 text-center text-xs text-[var(--muted)]">PantryChef · Chức năng 2: Gợi ý món từ nguyên liệu sẵn có</footer>
      </div>
    </main>
  );
}
