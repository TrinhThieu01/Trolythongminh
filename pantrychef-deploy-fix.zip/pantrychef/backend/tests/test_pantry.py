from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.dialects import postgresql
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
import pytest
from datetime import date, timedelta
from contextlib import asynccontextmanager

from app.database import Base, get_db
from app.main import app
from app.models import Ingredient, PantryItem

engine = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@asynccontextmanager
async def isolated_test_lifespan(_app):
    # Avoid creating/seeding the production-configured engine during tests.
    # Tests explicitly seed recipes in their isolated in-memory database.
    yield


app.router.lifespan_context = isolated_test_lifespan


def setup_function():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)



def test_create_list_update_delete_pantry_item():
    setup_function()
    with TestClient(app) as client:
        response = client.post("/api/pantry", json={
            "ingredient_name": "Trứng", "category": "Đạm", "quantity": 4,
            "unit": "quả", "expiry_date": "2026-10-25",
        })
        assert response.status_code == 201
        item = response.json()
        item_id = item["id"]
        assert item["ingredient_name"] == "Trứng"
        assert item["quantity"] == "4.000"

        listed = client.get("/api/pantry")
        assert listed.status_code == 200
        assert len(listed.json()) == 1

        updated = client.patch(f"/api/pantry/{item_id}", json={
            "quantity": 2, "expiry_date": None,
        })
        assert updated.status_code == 200
        assert updated.json()["quantity"] == "2.000"
        assert updated.json()["expiry_date"] is None

        deleted = client.delete(f"/api/pantry/{item_id}")
        assert deleted.status_code == 204
        assert client.get("/api/pantry").json() == []


@pytest.mark.parametrize("payload", [
    {"ingredient_name": "Cà chua", "quantity": -1, "unit": "kg"},
    {"ingredient_name": "Cà chua", "quantity": 0, "unit": "kg"},
    {"ingredient_name": "Cà chua", "quantity": "abc", "unit": "kg"},
    {"ingredient_name": "   ", "quantity": 1, "unit": "kg"},
    {"ingredient_name": "Cà chua", "quantity": 1, "unit": "thùng"},
    {"ingredient_name": "Cà chua", "quantity": 1, "unit": ""},
    {"ingredient_name": "Cà chua", "quantity": 1, "unit": "kilogram"},
    {"ingredient_name": "Cà chua", "quantity": 1, "unit": "kg", "expiry_date": "not-a-date"},
    {"ingredient_name": "C" * 151, "quantity": 1, "unit": "kg"},
    {"ingredient_name": "Cà chua", "quantity": 1, "unit": "kg", "category": "x" * 81},
])
def test_create_rejects_invalid_payloads(payload):
    setup_function()
    with TestClient(app) as client:
        response = client.post("/api/pantry", json=payload)
        assert response.status_code == 422
        assert client.get("/api/pantry").json() == []


def test_missing_expiry_is_allowed():
    setup_function()
    with TestClient(app) as client:
        response = client.post("/api/pantry", json={
            "ingredient_name": "Muối", "quantity": 1, "unit": "gói",
        })
        assert response.status_code == 201
        assert response.json()["expiry_date"] is None


def test_whitespace_in_ingredient_name_is_normalized():
    setup_function()
    with TestClient(app) as client:
        response = client.post("/api/pantry", json={
            "ingredient_name": "  Cà   chua  ", "quantity": 2, "unit": "quả",
        })
        assert response.status_code == 201
        assert response.json()["ingredient_name"] == "Cà chua"


def test_same_ingredient_can_have_separate_expiry_lots():
    setup_function()
    with TestClient(app) as client:
        for quantity, expiry in [(2, "2026-10-20"), (3, "2026-10-28")]:
            response = client.post("/api/pantry", json={
                "ingredient_name": "Sữa", "quantity": quantity,
                "unit": "ml", "expiry_date": expiry,
            })
            assert response.status_code == 201
        items = client.get("/api/pantry").json()
        assert len(items) == 2
        assert {item["ingredient_id"] for item in items}.__len__() == 1


def test_search_filters_by_ingredient_name():
    setup_function()
    with TestClient(app) as client:
        for name in ["Cà chua", "Trứng", "Hành lá"]:
            assert client.post("/api/pantry", json={
                "ingredient_name": name, "quantity": 1, "unit": "quả",
            }).status_code == 201
        response = client.get("/api/pantry", params={"search": "trứng"})
        assert response.status_code == 200
        assert [x["ingredient_name"] for x in response.json()] == ["Trứng"]


def test_patch_rejects_invalid_quantity():
    setup_function()
    with TestClient(app) as client:
        item = client.post("/api/pantry", json={
            "ingredient_name": "Gạo", "quantity": 1, "unit": "kg",
        }).json()
        response = client.patch(f"/api/pantry/{item['id']}", json={"quantity": -5})
        assert response.status_code == 422
        assert client.get("/api/pantry").json()[0]["quantity"] == "1.000"


def test_patch_missing_item_returns_404():
    setup_function()
    with TestClient(app) as client:
        response = client.patch("/api/pantry/999", json={"quantity": 2})
        assert response.status_code == 404


def test_delete_missing_item_returns_404():
    setup_function()
    with TestClient(app) as client:
        response = client.delete("/api/pantry/999")
        assert response.status_code == 404


def test_database_persists_rows_across_sessions():
    setup_function()
    with TestClient(app) as client:
        response = client.post("/api/pantry", json={
            "ingredient_name": "Đậu phụ", "quantity": 2, "unit": "miếng",
        })
        assert response.status_code == 201
    with TestingSessionLocal() as db:
        items = list(db.scalars(select(PantryItem)).all())
        ingredients = list(db.scalars(select(Ingredient)).all())
        assert len(items) == 1
        assert len(ingredients) == 1
        assert ingredients[0].name == "Đậu phụ"


def test_empty_pantry_returns_empty_list():
    setup_function()
    with TestClient(app) as client:
        response = client.get("/api/pantry")
        assert response.status_code == 200
        assert response.json() == []


@pytest.mark.parametrize("payload", [{"quantity": None}, {"unit": None}, {}])
def test_patch_rejects_null_required_or_empty_payload(payload):
    setup_function()
    with TestClient(app) as client:
        item = client.post("/api/pantry", json={
            "ingredient_name": "Bột mì", "quantity": 1, "unit": "g",
        }).json()
        response = client.patch(f"/api/pantry/{item['id']}", json=payload)
        assert response.status_code == 422
        assert client.get("/api/pantry").json()[0]["quantity"] == "1.000"

from app.recipe_catalog import seed_recipes


def test_recipe_catalog_has_at_least_twenty_curated_recipes():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
        assert db.query(__import__('app.models', fromlist=['Recipe']).Recipe).count() >= 20


def test_suggestions_use_real_pantry_and_return_missing_ingredients():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
    with TestClient(app) as client:
        client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 2, 'unit': 'quả'})
        client.post('/api/pantry', json={'ingredient_name': 'Cà chua', 'quantity': 150, 'unit': 'g'})
        response = client.get('/api/recipes/suggestions')
        assert response.status_code == 200
        data = response.json()
        assert data['count'] >= 20
        recipe = next(item for item in data['suggestions'] if item['slug'] == 'trung-chien-ca-chua')
        assert recipe['fit_score'] > 0
        assert recipe['missing_ingredients'] == [{'name': 'Dầu ăn', 'quantity': 10.0, 'unit': 'ml'}]


def test_recipe_suggestion_respects_quantity_and_unit_conversion():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
    with TestClient(app) as client:
        client.post('/api/pantry', json={'ingredient_name': 'Cà chua', 'quantity': 0.1, 'unit': 'kg'})
        client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 2, 'unit': 'quả'})
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-chien-ca-chua')
        assert recipe['ingredients'][0]['available'] is True
        assert recipe['ingredients'][1]['available'] is False
        assert recipe['missing_ingredients'][0]['name'] == 'Cà chua'


def test_expired_pantry_item_is_not_counted_for_recipe_suggestions():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
    with TestClient(app) as client:
        client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 2, 'unit': 'quả', 'expiry_date': '2000-01-01'})
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-luoc')
        assert recipe['fit_score'] == 0
        assert recipe['ingredients'][0]['available'] is False


def test_near_expiry_ingredients_increase_priority_and_fit_score():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
    from datetime import date, timedelta
    soon = (date.today() + timedelta(days=2)).isoformat()
    with TestClient(app) as client:
        client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 2, 'unit': 'quả', 'expiry_date': soon})
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-luoc')
        assert recipe['near_expiry_priority'] is True
        assert recipe['fit_score'] == 100
        assert recipe['ingredients'][0]['near_expiry'] is True


def test_min_fit_filter_and_limit_are_applied():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
    with TestClient(app) as client:
        response = client.get('/api/recipes/suggestions', params={'min_fit': 100, 'limit': 3})
        assert response.status_code == 200
        assert len(response.json()['suggestions']) <= 3
        assert all(item['fit_score'] >= 100 for item in response.json()['suggestions'])


@pytest.mark.parametrize('pantry_name,pantry_quantity,pantry_unit,expected', [
    ('Trứng', 2, 'quả', True), ('trứng', 2, 'quả', True), ('Trứng gà', 2, 'quả', True),
    ('Trứng', 1, 'quả', False), ('Trứng', 0.5, 'quả', False), ('Trứng', 2, 'gói', False),
    ('Trứng', 3, 'quả', True), ('Trứng', 2, 'quả', True), ('Trứng', 1.999, 'quả', False),
    ('Trứng', 10, 'quả', True), ('Trứng', 2, 'quả', True), ('Trứng', 0.001, 'quả', False),
    ('Trứng', 2, 'quả', True), ('Trứng', 1, 'quả', False), ('Trứng', 2, 'quả', True),
    ('Trứng', 2, 'quả', True), ('Trứng', 1.5, 'quả', False), ('Trứng', 2, 'quả', True),
    ('Trứng', 2, 'quả', True), ('Trứng', 0.25, 'quả', False),
])
def test_twenty_quantity_and_name_matching_scenarios(pantry_name, pantry_quantity, pantry_unit, expected):
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
    with TestClient(app) as client:
        response = client.post('/api/pantry', json={'ingredient_name': pantry_name, 'quantity': pantry_quantity, 'unit': pantry_unit})
        assert response.status_code == 201
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-luoc')
        assert recipe['ingredients'][0]['available'] is expected


def test_recipe_seeding_is_idempotent():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
        first_count = db.query(__import__('app.models', fromlist=['Recipe']).Recipe).count()
        seed_recipes(db)
        second_count = db.query(__import__('app.models', fromlist=['Recipe']).Recipe).count()
        assert first_count == second_count == 20


def test_empty_pantry_returns_only_curated_catalogue_with_zero_fit():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)
    with TestClient(app) as client:
        response = client.get('/api/recipes/suggestions')
        assert response.status_code == 200
        data = response.json()
        assert data['count'] == 20
        assert all(item['fit_score'] == 0 for item in data['suggestions'])
        assert all(item['missing_ingredients'] for item in data['suggestions'])


def test_suggestion_parameters_are_validated():
    setup_function()
    with TestClient(app) as client:
        assert client.get('/api/recipes/suggestions?min_fit=101').status_code == 422
        assert client.get('/api/recipes/suggestions?limit=0').status_code == 422


def _seed_recipe_catalogue_for_cooking():
    with TestingSessionLocal() as db:
        seed_recipes(db)


def test_cooking_session_requires_enough_non_expired_stock():
    setup_function()
    _seed_recipe_catalogue_for_cooking()
    with TestClient(app) as client:
        client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 1, 'unit': 'quả'})
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-luoc')
        response = client.post('/api/cooking-sessions', json={'recipe_id': recipe['id'], 'servings': 2})
        assert response.status_code == 409
        assert response.json()['detail']['missing_ingredients'][0]['name'] == 'Trứng'


def test_cooking_session_scales_ingredients_for_servings():
    setup_function()
    _seed_recipe_catalogue_for_cooking()
    with TestClient(app) as client:
        client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 4, 'unit': 'quả'})
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-luoc')
        response = client.post('/api/cooking-sessions', json={'recipe_id': recipe['id'], 'servings': 4})
        assert response.status_code == 201
        assert response.json()['status'] == 'in_progress'
        assert response.json()['ingredients'] == [{'name': 'Trứng', 'quantity': 4.0, 'unit': 'quả'}]
        assert len(response.json()['steps']) == 3


def test_complete_cooking_deducts_exact_stock_and_is_idempotent():
    from datetime import date, timedelta
    setup_function()
    _seed_recipe_catalogue_for_cooking()
    first_expiry = (date.today() + timedelta(days=1)).isoformat()
    second_expiry = (date.today() + timedelta(days=9)).isoformat()
    with TestClient(app) as client:
        first = client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 1, 'unit': 'quả', 'expiry_date': first_expiry}).json()
        second = client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 3, 'unit': 'quả', 'expiry_date': second_expiry}).json()
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-luoc')
        started = client.post('/api/cooking-sessions', json={'recipe_id': recipe['id'], 'servings': 2})
        assert started.status_code == 201
        session_id = started.json()['id']

        completed = client.post(f'/api/cooking-sessions/{session_id}/complete')
        assert completed.status_code == 200
        assert completed.json()['status'] == 'completed'
        assert sum(item['quantity'] for item in completed.json()['deductions']) == 2.0
        assert len(completed.json()['deductions']) == 2

        # Retrying completion must not subtract the same quantities twice.
        repeated = client.post(f'/api/cooking-sessions/{session_id}/complete')
        assert repeated.status_code == 200
        assert repeated.json()['deductions'] == completed.json()['deductions']
        pantry = {item['id']: item for item in client.get('/api/pantry').json()}
        assert pantry[first['id']]['quantity'] == '0.000'
        assert pantry[second['id']]['quantity'] == '2.000'


def test_expired_stock_cannot_be_used_to_start_or_complete_cooking():
    setup_function()
    _seed_recipe_catalogue_for_cooking()
    with TestClient(app) as client:
        client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 2, 'unit': 'quả', 'expiry_date': '2000-01-01'})
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-luoc')
        response = client.post('/api/cooking-sessions', json={'recipe_id': recipe['id'], 'servings': 2})
        assert response.status_code == 409
        assert client.get('/api/pantry').json()[0]['quantity'] == '2.000'


def test_cooking_completion_refuses_if_stock_changed_after_session_start():
    setup_function()
    _seed_recipe_catalogue_for_cooking()
    with TestClient(app) as client:
        item = client.post('/api/pantry', json={'ingredient_name': 'Trứng', 'quantity': 2, 'unit': 'quả'}).json()
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'trung-luoc')
        started = client.post('/api/cooking-sessions', json={'recipe_id': recipe['id'], 'servings': 2}).json()
        client.patch(f"/api/pantry/{item['id']}", json={'quantity': 1})
        response = client.post(f"/api/cooking-sessions/{started['id']}/complete")
        assert response.status_code == 409
        assert client.get('/api/pantry').json()[0]['quantity'] == '1.000'


def test_fractional_gram_deduction_preserves_precision_for_kg_stock():
    setup_function()
    _seed_recipe_catalogue_for_cooking()
    with TestClient(app) as client:
        client.post('/api/pantry', json={'ingredient_name': 'Thịt gà', 'quantity': 0.2, 'unit': 'kg'})
        ginger = client.post('/api/pantry', json={'ingredient_name': 'Gừng', 'quantity': 0.01, 'unit': 'kg'}).json()
        client.post('/api/pantry', json={'ingredient_name': 'Dầu ăn', 'quantity': 10, 'unit': 'ml'})
        recipe = next(item for item in client.get('/api/recipes/suggestions').json()['suggestions'] if item['slug'] == 'ga-xao-gung')
        started = client.post('/api/cooking-sessions', json={'recipe_id': recipe['id'], 'servings': 1})
        assert started.status_code == 201
        completed = client.post(f"/api/cooking-sessions/{started.json()['id']}/complete")
        assert completed.status_code == 200
        pantry = {item['id']: item for item in client.get('/api/pantry').json()}
        # 15 g ginger for 2 servings -> 7.5 g for 1 serving; 10 g in stock leaves 2.5 g.
        assert pantry[ginger['id']]['quantity'] == '0.002500'


def test_end_to_end_pantry_to_suggestion_to_cooking_deduction():
    """Acceptance flow across Features 1–3 using the same API and test database."""
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)

    with TestClient(app) as client:
        # Feature 1: add real pantry stock.
        egg = client.post("/api/pantry", json={
            "ingredient_name": "Trứng", "quantity": 4, "unit": "quả",
            "expiry_date": (date.today() + timedelta(days=2)).isoformat(),
        })
        assert egg.status_code == 201
        egg_item_id = egg.json()["id"]

        # Feature 2: suggestions are grounded in the pantry and show sufficient stock.
        suggestions_response = client.get("/api/recipes/suggestions")
        assert suggestions_response.status_code == 200
        boiled_eggs = next(
            item for item in suggestions_response.json()["suggestions"]
            if item["slug"] == "trung-luoc"
        )
        assert boiled_eggs["fit_score"] == 100
        assert boiled_eggs["ingredients"][0]["available"] is True

        # Feature 3: start, resume, complete, and verify exact stock mutation.
        started = client.post("/api/cooking-sessions", json={
            "recipe_id": boiled_eggs["id"], "servings": 2,
        })
        assert started.status_code == 201
        session_id = started.json()["id"]
        assert started.json()["status"] == "in_progress"
        assert len(started.json()["steps"]) >= 1

        resumed = client.get(f"/api/cooking-sessions/{session_id}")
        assert resumed.status_code == 200
        assert resumed.json()["status"] == "in_progress"

        completed = client.post(f"/api/cooking-sessions/{session_id}/complete")
        assert completed.status_code == 200
        assert completed.json()["status"] == "completed"
        assert sum(row["quantity"] for row in completed.json()["deductions"]) == 2

        pantry_after = client.get("/api/pantry").json()
        egg_after = next(item for item in pantry_after if item["id"] == egg_item_id)
        assert egg_after["quantity"] == "2.000"

        # A network retry must not deduct a second time.
        retried = client.post(f"/api/cooking-sessions/{session_id}/complete")
        assert retried.status_code == 200
        assert retried.json()["status"] == "completed"
        pantry_after_retry = client.get("/api/pantry").json()
        egg_after_retry = next(item for item in pantry_after_retry if item["id"] == egg_item_id)
        assert egg_after_retry["quantity"] == "2.000"


def test_end_to_end_refuses_to_start_when_pantry_is_insufficient():
    setup_function()
    with TestingSessionLocal() as db:
        seed_recipes(db)

    with TestClient(app) as client:
        recipe_response = client.get("/api/recipes/suggestions")
        recipe = next(
            item for item in recipe_response.json()["suggestions"]
            if item["slug"] == "trung-luoc"
        )
        client.post("/api/pantry", json={
            "ingredient_name": "Trứng", "quantity": 1, "unit": "quả",
        })
        response = client.post("/api/cooking-sessions", json={
            "recipe_id": recipe["id"], "servings": 2,
        })
        assert response.status_code == 409
        assert response.json()["detail"]["missing_ingredients"][0]["name"] == "Trứng"


def test_postgres_stock_lock_targets_only_pantry_table():
    # The completion query eager-loads Ingredient via an outer join. On
    # PostgreSQL, FOR UPDATE must target PantryItem only, not the nullable
    # side of that join. This dialect compilation test catches that regression
    # without pretending a PostgreSQL server is available in this runtime.
    statement = (
        select(PantryItem)
        .options(__import__("sqlalchemy.orm", fromlist=["joinedload"]).joinedload(PantryItem.ingredient))
        .order_by(PantryItem.expiry_date.asc().nullslast(), PantryItem.id.asc())
        .with_for_update(of=PantryItem)
    )
    sql = str(statement.compile(dialect=postgresql.dialect()))
    assert "FOR UPDATE OF pantry_items" in sql
    assert "FOR UPDATE OF ingredients" not in sql
