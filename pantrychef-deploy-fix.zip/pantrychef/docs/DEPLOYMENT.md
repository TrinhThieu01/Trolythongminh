# PantryChef deployment troubleshooting

## Fix the current Nixpacks error

The log says `Using subdirectory ".git"` and lists `HEAD`, `objects/`, `refs/`, and `packed-refs`. This means the deployment platform's **application/root directory is incorrectly set to `.git`**. Nixpacks is looking at Git metadata rather than the application source, so it cannot detect a framework or create a build plan. Changing dependencies or retrying the build will not fix this root cause.

### If deploying with Docker Compose (recommended for this repository)

- Set the repository/application root directory to `.` (the repository root), **not** `.git`.
- Select the repository's `docker-compose.yml` as the Compose file if the platform asks for it.
- Ensure the platform is deploying the commit that contains `docker-compose.yml`, `frontend/`, and `backend/`.
- Configure the database volume or managed PostgreSQL persistence before production use. Change the development database password.

### If deploying frontend and backend as separate services

This repository is a monorepo with two applications. Configure two services from the same repository:

**Frontend service**
- Root/build directory: `frontend`
- Build command: `npm install && npm run build` (or use `frontend/Dockerfile`)
- Start command: `npm run start` (or use `frontend/Dockerfile`)
- Build-time environment variable: `NEXT_PUBLIC_API_URL=https://<public-backend-domain>`

**Backend service**
- Root/build directory: `backend`
- Use `backend/Dockerfile`, or a Python build with `pip install -r requirements.txt` and start command `uvicorn app.main:app --host 0.0.0.0 --port $PORT` (the platform must provide a compatible Python runtime).
- Set `DATABASE_URL` to the managed PostgreSQL connection string.
- Set `CORS_ORIGINS` to the exact public frontend origin, such as `https://<frontend-domain>`.

Do not set either service's root directory to `.git`. Do not use `frontend` as the root for the Compose deployment; Compose needs the repository root so it can read `docker-compose.yml` and both service directories.

## Why the frontend API variable matters

`NEXT_PUBLIC_API_URL` is embedded into the browser bundle during `next build`. Setting it only as a runtime container environment variable can leave the deployed frontend pointing to `http://localhost:8000`, which refers to each visitor's own computer. The frontend Dockerfile now accepts a build argument and exports it before `npm run build`; `docker-compose.yml` supplies the local development URL as that build argument. For a separate hosted frontend, set the public backend URL as the build-time variable before building.

## Validate after fixing the source root

1. Re-run deployment and confirm the build log scans `.` (Compose) or `frontend`/`backend` (separate services), never `.git`.
2. Confirm frontend build completes.
3. Confirm backend `/health` returns success and `/docs` loads.
4. Open the frontend and inspect browser Network/Console: API requests must target the public backend domain, not `localhost`.
5. Test add/edit/delete pantry item, recipe suggestions, start/complete cooking, and confirm stock is deducted only once.
6. Verify database persistence after service restart.

The source-root diagnosis is directly supported by the supplied deployment log. This guide does not claim a successful hosted deployment; the corrected configuration still needs to be deployed and verified on the target platform.
