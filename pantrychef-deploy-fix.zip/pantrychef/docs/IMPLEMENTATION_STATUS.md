# PantryChef implementation status

## Feature 1 — Pantry management
Status: **BLOCKED — backend/API checks pass; frontend browser acceptance remains unverified**

### Implemented
- [x] FastAPI CRUD endpoints for pantry items
- [x] SQLAlchemy models for ingredients and pantry items
- [x] Validation for positive quantities, supported units, names and dates
- [x] Reject explicit null for required PATCH fields and reject empty PATCH payloads
- [x] Next.js pantry management screen (add/edit/delete/list/search)
- [x] Mutation flow distinguishes a successful save from a failed list refresh
- [x] PostgreSQL Docker Compose configuration

### Verification evidence
- [x] Backend pytest suite passes: **61 passed**, including cross-feature integration acceptance tests
- [x] Live FastAPI smoke test against a persistent SQLite database — create, edit, invalid quantity rejection, list and delete passed in prior verification
- [x] API process restart preserved a previously stored SQLite row in prior verification
- [ ] PostgreSQL container start and direct persistence verification (Docker and PostgreSQL server binaries are not installed in this runtime)
- [ ] Frontend dependency installation and production build (blocked: npm registry DNS lookup fails with `EAI_AGAIN registry.npmjs.org`; npm cache is empty)
- [ ] Open actual Next.js page in browser and interact with controls (blocked: dependencies cannot be installed; Chromium navigation to local pages is rejected by runtime policy)
- [ ] Verify browser refresh preserves rows via live API
- [ ] Verify UI behavior during API outage

Do not mark Feature 1 PASS until frontend build/browser acceptance and PostgreSQL verification pass.

## Feature 2 — Recipe suggestions from pantry
Status: **IMPLEMENTED — API tested; frontend/database acceptance incomplete**

### Implemented
- [x] Added `Recipe` and `RecipeIngredient` SQLAlchemy models
- [x] Added an idempotently seeded catalogue of 20 curated Vietnamese recipes
- [x] Added `GET /api/recipes/suggestions` with `min_fit` and `limit` validation
- [x] Match real pantry records to recipe requirements using normalized Vietnamese names and a small explicit alias map
- [x] Quantity matching for exact units and conversions between g/kg and ml/l
- [x] Show available/required amounts, missing ingredient amounts, match count, fit score and instructions
- [x] Exclude expired pantry lots from usable quantity; prioritize recipes with sufficiently available ingredients expiring within three days
- [x] Added `/recipes` Next.js screen with all/ready/near-expiry filters and expandable cooking steps
- [x] Added link from pantry page to recipe suggestions

### Verification evidence
- [x] Backend suite: 61 passed in the current suite (including 20 parametrized quantity/name scenarios and cross-feature acceptance tests)
- [x] `python -m compileall -q app` passed
- [x] Live Uvicorn smoke test with isolated SQLite database: `/health` returned 200; endpoint returned 20 recipes; after adding 2 eggs expiring soon, the boiled-egg recipe scored 100 and was flagged for near-expiry priority
- [x] Empty pantry returns the finite catalogue with zero fit; suggestions are only stored catalogue recipes
- [ ] PostgreSQL recipe seed and matching verification
- [ ] Frontend dependencies/build (blocked by npm DNS)
- [ ] Browser click-through on the actual Next.js page
- [ ] End-to-end acceptance across 20 scenarios using the deployed frontend and PostgreSQL

## Feature 3 — Guided cooking and exact stock deduction
Status: **BACKEND IMPLEMENTED AND TESTED; frontend/browser and PostgreSQL acceptance incomplete**

### Implemented
- [x] `CookingSession` records recipe, serving count, in-progress/completed state, and timestamps
- [x] `CookingDeduction` audit ledger records every pantry lot and amount deducted
- [x] `POST /api/cooking-sessions` starts a session only when requested servings have enough non-expired stock
- [x] Recipe quantities scale from catalogue servings to the selected servings
- [x] `GET /api/cooking-sessions/{id}` retrieves an active/completed session for resume
- [x] `POST /api/cooking-sessions/{id}/complete` revalidates stock, deducts atomically, and is idempotent on retry
- [x] FEFO stock allocation: consume earliest-expiring eligible lots first; expired lots are excluded
- [x] Fractional deductions preserve six decimal places, including grams stored as kilograms
- [x] Next.js cooking guide with checkable steps, serving selector, completion confirmation, and deduction ledger display
- [x] Active session ID is restored after a page refresh via localStorage and fetched from the API
- [x] PostgreSQL migration supplied at `backend/migrations/0003_cooking_sessions.sql`

### Verification evidence
- [x] Backend suite: 61 passed in the current suite
- [x] Tests cover insufficient stock, serving scaling, exact deduction across expiry lots, idempotent retries, expired stock exclusion, stock changed during cooking, and fractional-gram precision
- [x] `python -m compileall -q backend/app` passed
- [x] TypeScript/JSX syntax transpilation passed for both Next.js pages (full type-check/build still blocked by missing dependencies)
- [x] Live Uvicorn smoke test against isolated SQLite database: session start, step payload, exact deduction, zero stock, and idempotent retry passed
- [ ] PostgreSQL migration and row-locking verification
- [ ] Frontend dependency installation and production build (blocked: npm registry DNS lookup fails with `EAI_AGAIN registry.npmjs.org`)
- [ ] Open actual Next.js page in browser and click through cooking steps (blocked by frontend dependencies/runtime browser policy)

## Gate decision
Feature 3 backend logic and UI source are implemented, but end-to-end acceptance is incomplete. Features 1–3 must not be marked fully accepted until frontend build/browser checks and PostgreSQL verification are completed.


## Feature 4 — Cross-feature integration acceptance
Status: **BACKEND INTEGRATION PASS; browser/PostgreSQL acceptance remains blocked**

### Completed in this step
- [x] Added end-to-end API test: add pantry stock → retrieve recipe suggestions → start cooking → resume session → complete cooking → verify exact pantry stock → retry completion and verify no duplicate deduction
- [x] Added end-to-end rejection test when pantry quantity is insufficient to start a cooking session
- [x] Isolated the test app lifespan so pytest no longer creates or seeds the default `backend/pantrychef_test.db` file as a side effect
- [x] Full suite: **61 passed**
- [x] `python -m compileall -q app tests` passed
- [x] Live Uvicorn + isolated SQLite smoke test passed across all three features: health 200, 20 suggestions, eggs 4 → 2 after cooking, retry leaves quantity at 2
- [ ] Frontend production build and real-browser interaction (npm registry DNS fails with `EAI_AGAIN registry.npmjs.org`)
- [ ] PostgreSQL migration, persistence and concurrency verification (Docker/PostgreSQL not available in this runtime)

### Gate decision
The API workflow across Features 1–3 passes integration checks on SQLite. This is **not** full MVP acceptance: Next.js build/browser tests and PostgreSQL verification are still required before marking the project fully accepted.


## Step 5 — MVP environment hardening and acceptance preparation
Status: **PARTIAL — backend regression pass; live frontend/PostgreSQL runtime still blocked by environment**

### Completed in this step
- [x] Fixed PostgreSQL row-lock scope in cooking completion: `FOR UPDATE OF pantry_items` avoids attempting to lock the nullable `ingredients` side of an eager-loaded outer join.
- [x] Added a PostgreSQL-dialect SQL compilation regression test for the row-lock query.
- [x] Added the missing `@tailwindcss/postcss` dev dependency required by the existing Tailwind CSS v4 PostCSS configuration.
- [x] Backend test suite and Python compilation rerun after the changes.
- [ ] npm install and Next.js production build (registry DNS resolution unavailable in this runtime).
- [ ] Real-browser click-through (frontend dependencies unavailable; no claim of browser acceptance).
- [ ] Live PostgreSQL migration, persistence and concurrent-cooking test (no Docker/PostgreSQL server binary available).

### Gate decision
The backend remains regression-tested on SQLite and the PostgreSQL lock statement is dialect-compiled, but this is not a substitute for running a PostgreSQL server. MVP is not marked complete until the frontend build/browser tests and live PostgreSQL acceptance pass.
