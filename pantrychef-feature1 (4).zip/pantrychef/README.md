# PantryChef — MVP scaffold

This repository starts with **Feature 1 only: Pantry management**. Recipe recommendations and cooking flows are intentionally not implemented yet.

## Stack
- Frontend: Next.js App Router, TypeScript, Tailwind CSS
- Backend: FastAPI, SQLAlchemy, PostgreSQL
- Tests: pytest
- Local services: Docker Compose

## Run
1. Copy `backend/.env.example` to `backend/.env`.
2. From the project root run `docker compose up --build`.
3. Frontend: http://localhost:3000
4. Backend API docs: http://localhost:8000/docs
5. Backend health: http://localhost:8000/health

The frontend expects the API at `http://localhost:8000`. This is a development scaffold; run the checks below in an environment with Docker and Node/Python installed before treating the feature as accepted. See `docs/IMPLEMENTATION_STATUS.md` for the current verification evidence and blockers. The current execution environment cannot resolve `registry.npmjs.org` (`EAI_AGAIN`) and has no Docker/PostgreSQL server, so the frontend build, PostgreSQL persistence and browser acceptance remain pending.

## Test backend
```bash
cd backend
python -m venv .venv
# activate the virtual environment, then:
pip install -r requirements.txt
pytest -q
```

## Feature 1 acceptance checklist
- [ ] List pantry items
- [ ] Add pantry item
- [ ] Edit quantity, unit and expiry date
- [ ] Delete pantry item
- [ ] Reject negative quantities and invalid inputs
- [ ] Persist data in PostgreSQL
- [ ] Refresh page and verify data persists
- [ ] Empty state and API errors handled
- [ ] Browser interaction verified
- [ ] Database state verified
