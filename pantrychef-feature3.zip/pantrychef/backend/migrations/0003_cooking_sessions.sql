-- PostgreSQL migration for PantryChef Feature 3.
-- Back up the database before applying this migration.
-- Existing quantities keep their numeric value; the wider scale allows exact fractional deductions.
ALTER TABLE pantry_items ALTER COLUMN quantity TYPE NUMERIC(16, 6) USING quantity::NUMERIC(16, 6);
ALTER TABLE recipe_ingredients ALTER COLUMN quantity TYPE NUMERIC(16, 6) USING quantity::NUMERIC(16, 6);

CREATE TABLE IF NOT EXISTS cooking_sessions (
    id SERIAL PRIMARY KEY,
    recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE RESTRICT,
    servings INTEGER NOT NULL DEFAULT 2,
    status VARCHAR(20) NOT NULL DEFAULT 'in_progress',
    started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE NULL
);
CREATE INDEX IF NOT EXISTS ix_cooking_sessions_recipe_id ON cooking_sessions(recipe_id);
CREATE INDEX IF NOT EXISTS ix_cooking_sessions_status ON cooking_sessions(status);

CREATE TABLE IF NOT EXISTS cooking_deductions (
    id SERIAL PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES cooking_sessions(id) ON DELETE CASCADE,
    pantry_item_id INTEGER NOT NULL REFERENCES pantry_items(id) ON DELETE RESTRICT,
    ingredient_name VARCHAR(150) NOT NULL,
    quantity NUMERIC(16, 6) NOT NULL,
    unit VARCHAR(20) NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_cooking_deductions_session_id ON cooking_deductions(session_id);
CREATE INDEX IF NOT EXISTS ix_cooking_deductions_pantry_item_id ON cooking_deductions(pantry_item_id);
