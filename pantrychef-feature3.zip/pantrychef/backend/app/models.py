from datetime import date, datetime
from sqlalchemy import Date, DateTime, ForeignKey, Numeric, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

class Ingredient(Base):
    __tablename__ = "ingredients"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    category: Mapped[str | None] = mapped_column(String(80), nullable=True)
    default_unit: Mapped[str] = mapped_column(String(20), default="g")
    pantry_items: Mapped[list["PantryItem"]] = relationship(back_populates="ingredient")

class PantryItem(Base):
    __tablename__ = "pantry_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    ingredient_id: Mapped[int] = mapped_column(ForeignKey("ingredients.id", ondelete="RESTRICT"), index=True)
    quantity: Mapped[float] = mapped_column(Numeric(16, 6))
    unit: Mapped[str] = mapped_column(String(20))
    expiry_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    ingredient: Mapped[Ingredient] = relationship(back_populates="pantry_items")

class Recipe(Base):
    __tablename__ = "recipes"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    description: Mapped[str] = mapped_column(Text)
    minutes: Mapped[int] = mapped_column(default=20)
    servings: Mapped[int] = mapped_column(default=2)
    instructions: Mapped[str] = mapped_column(Text)
    recipe_ingredients: Mapped[list["RecipeIngredient"]] = relationship(back_populates="recipe", cascade="all, delete-orphan", order_by="RecipeIngredient.id")

class RecipeIngredient(Base):
    __tablename__ = "recipe_ingredients"
    id: Mapped[int] = mapped_column(primary_key=True)
    recipe_id: Mapped[int] = mapped_column(ForeignKey("recipes.id", ondelete="CASCADE"), index=True)
    ingredient_name: Mapped[str] = mapped_column(String(150), index=True)
    quantity: Mapped[float] = mapped_column(Numeric(16, 6))
    unit: Mapped[str] = mapped_column(String(20))
    recipe: Mapped[Recipe] = relationship(back_populates="recipe_ingredients")


class CookingSession(Base):
    __tablename__ = "cooking_sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    recipe_id: Mapped[int] = mapped_column(ForeignKey("recipes.id", ondelete="RESTRICT"), index=True)
    servings: Mapped[int] = mapped_column(default=2)
    status: Mapped[str] = mapped_column(String(20), default="in_progress", index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    recipe: Mapped[Recipe] = relationship()
    deductions: Mapped[list["CookingDeduction"]] = relationship(back_populates="session", cascade="all, delete-orphan")


class CookingDeduction(Base):
    __tablename__ = "cooking_deductions"
    id: Mapped[int] = mapped_column(primary_key=True)
    session_id: Mapped[int] = mapped_column(ForeignKey("cooking_sessions.id", ondelete="CASCADE"), index=True)
    pantry_item_id: Mapped[int] = mapped_column(ForeignKey("pantry_items.id", ondelete="RESTRICT"), index=True)
    ingredient_name: Mapped[str] = mapped_column(String(150))
    quantity: Mapped[float] = mapped_column(Numeric(16, 6))
    unit: Mapped[str] = mapped_column(String(20))
    session: Mapped[CookingSession] = relationship(back_populates="deductions")
    pantry_item: Mapped[PantryItem] = relationship()
