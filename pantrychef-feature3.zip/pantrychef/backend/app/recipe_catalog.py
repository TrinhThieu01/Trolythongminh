"""Curated, finite recipe catalogue. Suggestions must come from these records."""
from sqlalchemy import select
from sqlalchemy.orm import Session
from .models import Recipe, RecipeIngredient

# name, description, minutes, servings, instructions, [(ingredient, amount, unit), ...]
RECIPES = [
("trung-chien-ca-chua", "Trứng chiên cà chua", "Món nhanh, mềm thơm, hợp bữa cơm gia đình.", 12, 2, "1. Rửa và cắt cà chua. 2. Đánh trứng với chút muối. 3. Xào cà chua mềm, đổ trứng vào đảo chín.", [("Trứng", 2, "quả"), ("Cà chua", 150, "g"), ("Dầu ăn", 10, "ml")]),
("canh-ca-chua-trung", "Canh cà chua trứng", "Canh thanh nhẹ, nguyên liệu đơn giản.", 15, 2, "1. Đun sôi nước. 2. Cho cà chua vào nấu mềm. 3. Rót trứng đã đánh vào, khuấy nhẹ và nêm vừa ăn.", [("Trứng", 2, "quả"), ("Cà chua", 150, "g"), ("Hành lá", 10, "g")]),
("rau-muong-xao-toi", "Rau muống xào tỏi", "Món rau xào nhanh cho bữa cơm.", 10, 2, "1. Nhặt và rửa rau. 2. Phi thơm tỏi. 3. Xào rau trên lửa lớn, nêm vừa ăn.", [("Rau muống", 300, "g"), ("Tỏi", 10, "g"), ("Dầu ăn", 10, "ml")]),
("dau-phu-sot-ca", "Đậu phụ sốt cà chua", "Đậu phụ mềm, sốt cà chua đậm vị.", 20, 2, "1. Cắt đậu phụ và áp chảo nhẹ. 2. Xào cà chua đến mềm. 3. Cho đậu vào sốt 5–7 phút.", [("Đậu phụ", 300, "g"), ("Cà chua", 200, "g"), ("Hành lá", 10, "g")]),
("ga-xao-gung", "Gà xào gừng", "Món mặn thơm gừng, dễ ăn với cơm.", 25, 2, "1. Thái gà miếng vừa ăn, ướp gia vị. 2. Phi gừng. 3. Xào gà chín hoàn toàn.", [("Thịt gà", 300, "g"), ("Gừng", 15, "g"), ("Dầu ăn", 10, "ml")]),
("thit-heo-xao-hanh", "Thịt heo xào hành", "Món xào đơn giản cho ngày bận rộn.", 20, 2, "1. Thái thịt mỏng, thái hành. 2. Xào thịt đến gần chín. 3. Thêm hành và đảo chín.", [("Thịt heo", 250, "g"), ("Hành tây", 100, "g"), ("Dầu ăn", 10, "ml")]),
("trung-luoc", "Trứng luộc", "Món đơn giản, ít thao tác.", 10, 2, "1. Cho trứng vào nồi nước. 2. Đun sôi rồi luộc 8–10 phút. 3. Làm nguội và bóc vỏ.", [("Trứng", 2, "quả")]),
("com-chien-trung", "Cơm chiên trứng", "Tận dụng cơm nguội và trứng sẵn có.", 15, 2, "1. Đánh trứng. 2. Phi thơm hành nếu có, cho trứng và cơm vào đảo tơi. 3. Nêm vừa ăn.", [("Cơm nguội", 300, "g"), ("Trứng", 2, "quả"), ("Dầu ăn", 10, "ml")]),
("mi-xao-rau", "Mì xào rau củ", "Món mì xào linh hoạt với rau sẵn có.", 15, 2, "1. Chần mì theo hướng dẫn. 2. Xào rau củ. 3. Thêm mì, đảo đều và nêm gia vị.", [("Mì", 200, "g"), ("Cà rốt", 100, "g"), ("Cải thìa", 150, "g")]),
("canh-bi-do", "Canh bí đỏ", "Canh ngọt tự nhiên, dễ nấu.", 25, 2, "1. Gọt bí và cắt miếng. 2. Nấu bí với nước đến mềm. 3. Nêm vừa ăn.", [("Bí đỏ", 300, "g"), ("Hành lá", 10, "g")]),
("salad-dua-chuot-ca-chua", "Salad dưa chuột cà chua", "Món tươi mát, không cần nấu.", 10, 2, "1. Rửa sạch rau củ. 2. Thái lát. 3. Trộn cùng dầu giấm hoặc nước sốt có sẵn.", [("Dưa chuột", 200, "g"), ("Cà chua", 150, "g")]),
("ca-hoi-ap-chao", "Cá áp chảo", "Áp chảo cá đến chín, giữ phần thịt ẩm.", 18, 2, "1. Thấm khô cá, nêm gia vị. 2. Làm nóng chảo với dầu. 3. Áp chảo đến khi cá chín an toàn.", [("Cá hồi", 250, "g"), ("Chanh", 1, "quả"), ("Dầu ăn", 10, "ml")]),
("thit-bo-xao-rau", "Thịt bò xào rau", "Món xào nhanh, cần chuẩn bị nguyên liệu trước.", 18, 2, "1. Thái bò mỏng. 2. Xào bò nhanh rồi gắp ra. 3. Xào rau, cho bò lại đảo chín.", [("Thịt bò", 250, "g"), ("Cải thìa", 200, "g"), ("Tỏi", 10, "g")]),
("khoai-tay-chien", "Khoai tây áp chảo", "Khoai vàng cạnh, dùng làm món ăn kèm.", 25, 2, "1. Gọt và thái khoai. 2. Luộc sơ 5 phút rồi để ráo. 3. Áp chảo với dầu đến vàng và chín.", [("Khoai tây", 300, "g"), ("Dầu ăn", 15, "ml")]),
("chao-yen-mach", "Cháo yến mạch", "Bữa sáng ấm bụng, dễ điều chỉnh độ đặc.", 10, 1, "1. Đun yến mạch với nước hoặc sữa. 2. Khuấy đến độ đặc mong muốn. 3. Dùng nóng.", [("Yến mạch", 50, "g"), ("Sữa", 200, "ml")]),
("banh-mi-trung", "Bánh mì trứng", "Bữa sáng nhanh gọn.", 10, 1, "1. Chiên trứng chín. 2. Làm nóng bánh mì. 3. Kẹp trứng và rau nếu có.", [("Bánh mì", 1, "ổ"), ("Trứng", 1, "quả")]),
("canh-rau-ngot-thit", "Canh rau ngót thịt băm", "Canh rau ngót nấu thịt băm.", 20, 2, "1. Vò nhẹ rau ngót đã rửa. 2. Xào thịt băm. 3. Thêm nước và rau, nấu chín.", [("Rau ngót", 250, "g"), ("Thịt heo", 150, "g")]),
("tom-rim", "Tôm rim", "Món mặn đậm đà, ăn cùng cơm.", 20, 2, "1. Rửa tôm và để ráo. 2. Phi thơm hành tỏi. 3. Rim tôm với gia vị đến khi chín.", [("Tôm", 300, "g"), ("Tỏi", 10, "g")]),
("nam-xao-trung", "Nấm xào trứng", "Món xào mềm thơm, làm nhanh.", 12, 2, "1. Làm sạch nấm. 2. Xào nấm đến chín. 3. Thêm trứng đánh tan, đảo chín.", [("Nấm", 200, "g"), ("Trứng", 2, "quả")]),
("dau-hu-non-sot-xi-dau", "Đậu hũ sốt xì dầu", "Món đậu hũ nhẹ nhàng, phù hợp bữa cơm.", 15, 2, "1. Cắt đậu hũ. 2. Đun xì dầu cùng ít nước. 3. Cho đậu vào rim nhẹ, thêm hành nếu có.", [("Đậu phụ", 300, "g"), ("Xì dầu", 15, "ml"), ("Hành lá", 10, "g")]),
]

def seed_recipes(db: Session) -> None:
    existing = set(db.scalars(select(Recipe.slug)).all())
    for slug, name, description, minutes, servings, instructions, ingredients in RECIPES:
        if slug in existing:
            continue
        recipe = Recipe(slug=slug, name=name, description=description, minutes=minutes, servings=servings, instructions=instructions)
        recipe.recipe_ingredients = [RecipeIngredient(ingredient_name=ing, quantity=qty, unit=unit) for ing, qty, unit in ingredients]
        db.add(recipe)
    db.commit()
