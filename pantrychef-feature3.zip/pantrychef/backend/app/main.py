from contextlib import asynccontextmanager
from datetime import date, datetime, timezone
from decimal import Decimal
import os

from fastapi import Depends, FastAPI, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from .database import Base, engine, get_db
from .models import CookingDeduction, CookingSession, Ingredient, PantryItem, Recipe
from .recipe_catalog import seed_recipes
from .schemas import CookingSessionCreate, IngredientOut, PantryCreate, PantryOut, PantryUpdate

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    from .database import SessionLocal
    with SessionLocal() as db:
        seed_recipes(db)
    yield

app = FastAPI(title="PantryChef API", version="0.1.0", lifespan=lifespan)
origins = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in origins],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def to_pantry_out(item: PantryItem) -> PantryOut:
    return PantryOut(
        id=item.id,
        ingredient_id=item.ingredient_id,
        ingredient_name=item.ingredient.name,
        category=item.ingredient.category,
        quantity=(
            Decimal(item.quantity).quantize(Decimal("0.001"))
            if Decimal(item.quantity) == Decimal(item.quantity).quantize(Decimal("0.001"))
            else Decimal(item.quantity).quantize(Decimal("0.000001"))
        ),
        unit=item.unit,
        expiry_date=item.expiry_date,
        updated_at=item.updated_at,
    )

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/api/ingredients", response_model=list[IngredientOut])
def list_ingredients(db: Session = Depends(get_db)):
    return list(db.scalars(select(Ingredient).order_by(Ingredient.name)).all())

@app.get("/api/pantry", response_model=list[PantryOut])
def list_pantry(
    search: str | None = Query(default=None, max_length=100),
    db: Session = Depends(get_db),
):
    stmt = select(PantryItem).options(joinedload(PantryItem.ingredient)).order_by(PantryItem.id.desc())
    items = list(db.scalars(stmt).unique().all())
    if search:
        needle = search.casefold().strip()
        items = [item for item in items if needle in item.ingredient.name.casefold()]
    return [to_pantry_out(item) for item in items]

@app.post("/api/pantry", response_model=PantryOut, status_code=201)
def create_pantry(payload: PantryCreate, db: Session = Depends(get_db)):
    name = payload.ingredient_name
    ingredient = db.scalar(select(Ingredient).where(Ingredient.name.ilike(name)))
    if ingredient is None:
        ingredient = Ingredient(
            name=name,
            category=payload.category,
            default_unit=payload.unit,
        )
        db.add(ingredient)
        try:
            db.flush()
        except IntegrityError:
            db.rollback()
            ingredient = db.scalar(select(Ingredient).where(Ingredient.name.ilike(name)))
            if ingredient is None:
                raise HTTPException(status_code=409, detail="Nguyên liệu đã tồn tại; vui lòng thử lại")
    elif payload.category and not ingredient.category:
        ingredient.category = payload.category

    item = PantryItem(
        ingredient=ingredient,
        quantity=payload.quantity,
        unit=payload.unit,
        expiry_date=payload.expiry_date,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return to_pantry_out(item)

@app.patch("/api/pantry/{item_id}", response_model=PantryOut)
def update_pantry(item_id: int, payload: PantryUpdate, db: Session = Depends(get_db)):
    item = db.scalar(
        select(PantryItem).options(joinedload(PantryItem.ingredient)).where(PantryItem.id == item_id)
    )
    if item is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy nguyên liệu trong kho")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(item, field, value)
    db.commit()
    db.refresh(item)
    return to_pantry_out(item)

@app.delete("/api/pantry/{item_id}", status_code=204)
def delete_pantry(item_id: int, db: Session = Depends(get_db)):
    item = db.get(PantryItem, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy nguyên liệu trong kho")
    db.delete(item)
    db.commit()
    return Response(status_code=204)


# Matching rules are deliberately deterministic: the app only recommends recipes
# stored in the curated database catalogue; it does not invent dish names.
import unicodedata

def normalize_food_name(value: str) -> str:
    text = unicodedata.normalize("NFD", value.casefold().strip())
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    text = text.replace("đ", "d")
    return " ".join(text.split())

ALIASES = {
    "trung ga": "trung", "trung vit": "trung", "ca chua bi": "ca chua",
    "dau hu": "dau phu", "rau muong bo": "rau muong",
    "hanh la": "hanh la", "hanh hoa": "hanh la", "thit lon": "thit heo",
    "thit ga ta": "thit ga", "dau an": "dau an",
}

def canonical_food(value: str) -> str:
    normalized = normalize_food_name(value)
    return ALIASES.get(normalized, normalized)

def convert_quantity(quantity: Decimal, source_unit: str, target_unit: str) -> Decimal | None:
    source_unit, target_unit = source_unit.strip().lower(), target_unit.strip().lower()
    if source_unit == target_unit:
        return quantity
    mass = {"g": Decimal("1"), "kg": Decimal("1000")}
    volume = {"ml": Decimal("1"), "l": Decimal("1000")}
    if source_unit in mass and target_unit in mass:
        return quantity * mass[source_unit] / mass[target_unit]
    if source_unit in volume and target_unit in volume:
        return quantity * volume[source_unit] / volume[target_unit]
    return None

def recipe_to_suggestion(recipe: Recipe, pantry_items: list[PantryItem], today: date) -> dict:
    ingredients = []
    missing = []
    matched_count = 0
    near_expiry_match = False
    for required in recipe.recipe_ingredients:
        target_name = canonical_food(required.ingredient_name)
        compatible_total = Decimal("0")
        found_any = False
        has_near_expiry = False
        for item in pantry_items:
            if canonical_food(item.ingredient.name) != target_name:
                continue
            if item.expiry_date is not None and item.expiry_date < today:
                continue
            converted = convert_quantity(Decimal(item.quantity), item.unit, required.unit)
            if converted is None:
                continue
            compatible_total += converted
            found_any = True
            if item.expiry_date is not None and 0 <= (item.expiry_date - today).days <= 3:
                has_near_expiry = True
        needed = Decimal(required.quantity)
        enough = found_any and compatible_total >= needed
        if enough:
            matched_count += 1
            near_expiry_match = near_expiry_match or has_near_expiry
        missing_amount = max(Decimal("0"), needed - compatible_total)
        detail = {
            "name": required.ingredient_name, "required_quantity": float(needed),
            "unit": required.unit, "available_quantity": float(compatible_total),
            "available": bool(enough), "near_expiry": bool(has_near_expiry and enough),
        }
        ingredients.append(detail)
        if not enough:
            missing.append({"name": required.ingredient_name, "quantity": float(missing_amount if found_any else needed), "unit": required.unit})
    base_score = round(100 * matched_count / len(recipe.recipe_ingredients)) if recipe.recipe_ingredients else 0
    score = min(100, base_score + (10 if near_expiry_match else 0))
    return {
        "id": recipe.id, "slug": recipe.slug, "name": recipe.name, "description": recipe.description,
        "minutes": recipe.minutes, "servings": recipe.servings, "instructions": recipe.instructions,
        "fit_score": score, "matched_ingredients": matched_count, "total_ingredients": len(recipe.recipe_ingredients),
        "near_expiry_priority": near_expiry_match, "ingredients": ingredients, "missing_ingredients": missing,
    }

@app.get("/api/recipes/suggestions")
def suggest_recipes(
    min_fit: int = Query(default=0, ge=0, le=100),
    limit: int = Query(default=20, ge=1, le=50),
    db: Session = Depends(get_db),
):
    pantry = list(db.scalars(select(PantryItem).options(joinedload(PantryItem.ingredient))).unique().all())
    recipes = list(db.scalars(select(Recipe).options(joinedload(Recipe.recipe_ingredients)).order_by(Recipe.id)).unique().all())
    today = date.today()
    suggestions = [recipe_to_suggestion(recipe, pantry, today) for recipe in recipes]
    suggestions = [item for item in suggestions if item["fit_score"] >= min_fit]
    suggestions.sort(key=lambda item: (item["near_expiry_priority"], item["fit_score"], item["matched_ingredients"]), reverse=True)
    return {"count": len(suggestions), "pantry_item_count": len(pantry), "suggestions": suggestions[:limit]}


def scaled_recipe_requirements(recipe: Recipe, servings: int) -> list[dict]:
    scale = Decimal(servings) / Decimal(recipe.servings)
    return [
        {
            "name": ingredient.ingredient_name,
            "quantity": (Decimal(ingredient.quantity) * scale).quantize(Decimal("0.001")),
            "unit": ingredient.unit,
        }
        for ingredient in recipe.recipe_ingredients
    ]

def cooking_session_payload(session: CookingSession, db: Session) -> dict:
    recipe = db.scalar(
        select(Recipe).options(joinedload(Recipe.recipe_ingredients)).where(Recipe.id == session.recipe_id)
    )
    if recipe is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy công thức")
    deductions = list(db.scalars(select(CookingDeduction).where(CookingDeduction.session_id == session.id).order_by(CookingDeduction.id)).all())
    instructions = [part.strip() for part in __import__("re").split(r"(?<=\.)\s+(?=\d+\.)", recipe.instructions) if part.strip()]
    if not instructions:
        instructions = [recipe.instructions.strip()]
    return {
        "id": session.id, "recipe_id": recipe.id, "recipe_name": recipe.name,
        "servings": session.servings, "status": session.status,
        "started_at": session.started_at, "completed_at": session.completed_at,
        "minutes": recipe.minutes, "steps": instructions,
        "ingredients": scaled_recipe_requirements(recipe, session.servings),
        "deductions": [
            {"pantry_item_id": row.pantry_item_id, "ingredient_name": row.ingredient_name,
             "quantity": float(row.quantity), "unit": row.unit}
            for row in deductions
        ],
    }

@app.post("/api/cooking-sessions", status_code=201)
def start_cooking_session(payload: CookingSessionCreate, db: Session = Depends(get_db)):
    recipe = db.scalar(
        select(Recipe).options(joinedload(Recipe.recipe_ingredients)).where(Recipe.id == payload.recipe_id)
    )
    if recipe is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy công thức")
    pantry = list(db.scalars(select(PantryItem).options(joinedload(PantryItem.ingredient))).unique().all())
    requirements = scaled_recipe_requirements(recipe, payload.servings)
    # Check at the requested serving count, not merely at the catalogue default.
    missing = []
    for required in requirements:
        available = Decimal("0")
        for item in pantry:
            if canonical_food(item.ingredient.name) != canonical_food(required["name"]):
                continue
            if item.expiry_date is not None and item.expiry_date < date.today():
                continue
            converted = convert_quantity(Decimal(item.quantity), item.unit, required["unit"])
            if converted is not None:
                available += converted
        if available < required["quantity"]:
            missing.append({"name": required["name"], "required_quantity": float(required["quantity"]),
                            "available_quantity": float(available), "unit": required["unit"]})
    if missing:
        raise HTTPException(status_code=409, detail={
            "message": "Kho chưa đủ nguyên liệu để bắt đầu nấu. Hãy bổ sung hoặc giảm số phần.",
            "missing_ingredients": missing,
        })
    session = CookingSession(recipe_id=recipe.id, servings=payload.servings, status="in_progress")
    db.add(session)
    db.commit()
    db.refresh(session)
    return cooking_session_payload(session, db)

@app.get("/api/cooking-sessions/{session_id}")
def get_cooking_session(session_id: int, db: Session = Depends(get_db)):
    session = db.get(CookingSession, session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy phiên nấu")
    return cooking_session_payload(session, db)

@app.post("/api/cooking-sessions/{session_id}/complete")
def complete_cooking_session(session_id: int, db: Session = Depends(get_db)):
    session = db.scalar(select(CookingSession).where(CookingSession.id == session_id).with_for_update())
    if session is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy phiên nấu")
    if session.status == "completed":
        # Idempotent completion: retrying this request never deducts stock twice.
        return cooking_session_payload(session, db)

    recipe = db.scalar(
        select(Recipe).options(joinedload(Recipe.recipe_ingredients)).where(Recipe.id == session.recipe_id)
    )
    if recipe is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy công thức")
    today = date.today()
    pantry = list(db.scalars(
        select(PantryItem).options(joinedload(PantryItem.ingredient))
        .order_by(PantryItem.expiry_date.asc().nullslast(), PantryItem.id.asc()).with_for_update()
    ).unique().all())
    requirements = scaled_recipe_requirements(recipe, session.servings)
    plan: list[tuple[PantryItem, Decimal, str, str]] = []
    missing = []
    for required in requirements:
        remaining = required["quantity"]
        eligible = [item for item in pantry if canonical_food(item.ingredient.name) == canonical_food(required["name"])]
        eligible = [item for item in eligible if item.expiry_date is None or item.expiry_date >= today]
        for item in eligible:
            if remaining <= 0:
                break
            available_in_required_unit = convert_quantity(Decimal(item.quantity), item.unit, required["unit"])
            if available_in_required_unit is None or available_in_required_unit <= 0:
                continue
            take_required_unit = min(available_in_required_unit, remaining)
            take_native_unit = convert_quantity(take_required_unit, required["unit"], item.unit)
            if take_native_unit is None:
                continue
            take_native_unit = take_native_unit.quantize(Decimal("0.000001"))
            plan.append((item, take_native_unit, item.ingredient.name, item.unit))
            remaining -= convert_quantity(take_native_unit, item.unit, required["unit"]) or Decimal("0")
        if remaining > Decimal("0.0000005"):
            missing.append({"name": required["name"], "quantity": float(remaining.quantize(Decimal("0.000001"))), "unit": required["unit"]})
    if missing:
        db.rollback()
        raise HTTPException(status_code=409, detail={
            "message": "Kho đã thay đổi trong lúc nấu; không trừ kho vì nguyên liệu hiện không đủ.",
            "missing_ingredients": missing,
        })

    for item, quantity, ingredient_name, unit in plan:
        item.quantity = (Decimal(item.quantity) - quantity).quantize(Decimal("0.000001"))
        db.add(CookingDeduction(session_id=session.id, pantry_item_id=item.id,
                                ingredient_name=ingredient_name, quantity=quantity, unit=unit))
    session.status = "completed"
    session.completed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(session)
    return cooking_session_payload(session, db)
