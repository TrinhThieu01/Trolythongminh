# PantryChef — MVP scaffold

PantryChef is a Vietnamese-language cooking assistant based on ingredients actually recorded in the pantry. The current codebase contains Feature 1 (pantry management), Feature 2 (recipe suggestions from the stored pantry and a curated database catalogue), and Feature 3 (guided cooking with audited stock deduction). Backend logic has automated and live API checks. The cross-feature API flow (pantry → suggestions → cooking → exact deduction → idempotent retry) passes; browser/PostgreSQL acceptance remains incomplete in the current runtime.

## Stack
- Frontend: Next.js App Router, TypeScript, Tailwind CSS
- Backend: FastAPI, SQLAlchemy
- Database target: PostgreSQL via Docker Compose; SQLite was used only for local verification
- Tests: pytest

## Run
1. Copy `backend/.env.example` to `backend/.env` and set `DATABASE_URL` for your PostgreSQL instance.
2. From the project root run `docker compose up --build` in an environment with Docker available.
3. Pantry management: http://localhost:3000
4. Recipe suggestions: http://localhost:3000/recipes
5. Backend API docs: http://localhost:8000/docs
6. Backend health: http://localhost:8000/health

The frontend expects the API at `http://localhost:8000` by default. Cooking-session endpoints are `POST /api/cooking-sessions`, `GET /api/cooking-sessions/{session_id}`, and `POST /api/cooking-sessions/{session_id}/complete`. Completion revalidates stock and deducts from earliest-expiring eligible lots first; retries do not deduct twice. The quantity scale supports fractional deductions such as 7.5 g when the pantry lot is stored in kg. The recipe suggestion API is `GET /api/recipes/suggestions?min_fit=0&limit=20`. Recipes come only from the curated database catalogue; no recipe names are invented by a generative model. Ingredient matching checks normalized names, supported unit conversions (g/kg and ml/l), required quantities, expiry dates, missing ingredients, fit score and near-expiry priority. Expired pantry lots are not counted as usable stock.

The current execution environment cannot resolve `registry.npmjs.org` (`EAI_AGAIN`) and does not provide Docker/PostgreSQL. TypeScript/JSX syntax transpilation passes, but the Next.js production build, PostgreSQL persistence, and actual browser interaction remain unverified. See `docs/IMPLEMENTATION_STATUS.md` for the evidence and blockers. Do not claim browser acceptance based only on backend tests.

## Integration acceptance (Step 4)
The test suite includes a cross-feature acceptance flow and a rejection case for insufficient stock. Run `cd backend && python -m pytest -q`; the current result is **60 passed**. The live API smoke test also confirmed that 4 eggs become 2 after cooking a 2-serving boiled-egg recipe, and retrying completion leaves the stock at 2. These checks used isolated SQLite; they do not replace PostgreSQL or browser verification.

## Test backend
```bash
cd backend
python -m venv .venv
# activate the virtual environment, then:
pip install -r requirements.txt
pytest -q
```

## Feature 1 — Pantry management acceptance
- [ ] List, add, edit, search and delete pantry items in the real browser
- [x] Reject negative quantities and invalid inputs (API tests)
- [x] API CRUD and SQLite persistence across API restart (smoke test)
- [ ] Persist data in PostgreSQL
- [ ] Refresh page and verify data persists
- [ ] Verify empty state and API outage behavior in browser

## Feature 2 — Recipe suggestions acceptance
- [x] Curated database catalogue of 20 recipes, seeded idempotently
- [x] Match recipe ingredients to pantry entries using normalized names and aliases
- [x] Check quantities and supported g/kg, ml/l conversions
- [x] Show missing ingredient quantities and fit score
- [x] Ignore expired stock and prioritize recipes using sufficiently available near-expiry stock
- [x] 20 parametrized quantity/name matching scenarios, plus API integration tests
- [ ] Frontend build and actual browser click-through
- [ ] PostgreSQL recipe seed and suggestion verification
- [ ] Acceptance over 20 end-to-end pantry scenarios in the deployed stack

## Feature 3 database migration
For an existing PostgreSQL database, back up the database and apply `backend/migrations/0003_cooking_sessions.sql` before deploying Feature 3. Fresh databases create the new tables from SQLAlchemy metadata automatically. The migration expands quantity precision to support fractional deductions (for example, 7.5 g stored as 0.0075 kg).

## Feature 3 — Guided cooking and stock deduction
- [x] Start a cooking session only when enough non-expired ingredients are available for the selected serving count
- [x] Show scaled ingredient quantities and individual cooking steps
- [x] Deduct stock atomically on completion and record each lot deduction
- [x] Prefer earliest-expiring eligible lots and exclude expired lots
- [x] Prevent duplicate deductions when completion is retried
- [x] Backend tests and live Uvicorn smoke test
- [ ] Frontend production build and browser click-through
- [ ] PostgreSQL migration, concurrency and persistence verification
