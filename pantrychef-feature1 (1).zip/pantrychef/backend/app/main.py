from contextlib import asynccontextmanager
from datetime import date
from decimal import Decimal
import os

from fastapi import Depends, FastAPI, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from .database import Base, engine, get_db
from .models import Ingredient, PantryItem
from .schemas import IngredientOut, PantryCreate, PantryOut, PantryUpdate

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield

app = FastAPI(title="PantryChef API", version="0.1.0", lifespan=lifespan)
origins = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in origins],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def to_pantry_out(item: PantryItem) -> PantryOut:
    return PantryOut(
        id=item.id,
        ingredient_id=item.ingredient_id,
        ingredient_name=item.ingredient.name,
        category=item.ingredient.category,
        quantity=item.quantity,
        unit=item.unit,
        expiry_date=item.expiry_date,
        updated_at=item.updated_at,
    )

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/api/ingredients", response_model=list[IngredientOut])
def list_ingredients(db: Session = Depends(get_db)):
    return list(db.scalars(select(Ingredient).order_by(Ingredient.name)).all())

@app.get("/api/pantry", response_model=list[PantryOut])
def list_pantry(
    search: str | None = Query(default=None, max_length=100),
    db: Session = Depends(get_db),
):
    stmt = select(PantryItem).options(joinedload(PantryItem.ingredient)).order_by(PantryItem.id.desc())
    items = list(db.scalars(stmt).unique().all())
    if search:
        needle = search.casefold().strip()
        items = [item for item in items if needle in item.ingredient.name.casefold()]
    return [to_pantry_out(item) for item in items]

@app.post("/api/pantry", response_model=PantryOut, status_code=201)
def create_pantry(payload: PantryCreate, db: Session = Depends(get_db)):
    name = payload.ingredient_name
    ingredient = db.scalar(select(Ingredient).where(Ingredient.name.ilike(name)))
    if ingredient is None:
        ingredient = Ingredient(
            name=name,
            category=payload.category,
            default_unit=payload.unit,
        )
        db.add(ingredient)
        try:
            db.flush()
        except IntegrityError:
            db.rollback()
            ingredient = db.scalar(select(Ingredient).where(Ingredient.name.ilike(name)))
            if ingredient is None:
                raise HTTPException(status_code=409, detail="Nguyên liệu đã tồn tại; vui lòng thử lại")
    elif payload.category and not ingredient.category:
        ingredient.category = payload.category

    item = PantryItem(
        ingredient=ingredient,
        quantity=payload.quantity,
        unit=payload.unit,
        expiry_date=payload.expiry_date,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return to_pantry_out(item)

@app.patch("/api/pantry/{item_id}", response_model=PantryOut)
def update_pantry(item_id: int, payload: PantryUpdate, db: Session = Depends(get_db)):
    item = db.scalar(
        select(PantryItem).options(joinedload(PantryItem.ingredient)).where(PantryItem.id == item_id)
    )
    if item is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy nguyên liệu trong kho")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(item, field, value)
    db.commit()
    db.refresh(item)
    return to_pantry_out(item)

@app.delete("/api/pantry/{item_id}", status_code=204)
def delete_pantry(item_id: int, db: Session = Depends(get_db)):
    item = db.get(PantryItem, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Không tìm thấy nguyên liệu trong kho")
    db.delete(item)
    db.commit()
    return Response(status_code=204)
