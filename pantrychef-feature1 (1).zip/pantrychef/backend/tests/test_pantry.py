from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app

engine = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

with TestClient(app) as client:
    pass

def setup_function():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

def test_create_list_update_delete_pantry_item():
    setup_function()
    with TestClient(app) as client:
        response = client.post("/api/pantry", json={
            "ingredient_name": "Trứng",
            "category": "Đạm",
            "quantity": 4,
            "unit": "quả",
            "expiry_date": "2026-10-25",
        })
        assert response.status_code == 201
        item = response.json()
        item_id = item["id"]
        assert item["ingredient_name"] == "Trứng"
        assert item["quantity"] == "4.000"

        listed = client.get("/api/pantry")
        assert listed.status_code == 200
        assert len(listed.json()) == 1

        updated = client.patch(f"/api/pantry/{item_id}", json={
            "quantity": 2,
            "expiry_date": None,
        })
        assert updated.status_code == 200
        assert updated.json()["quantity"] == "2.000"
        assert updated.json()["expiry_date"] is None

        deleted = client.delete(f"/api/pantry/{item_id}")
        assert deleted.status_code == 204
        assert client.get("/api/pantry").json() == []

def test_reject_negative_quantity_and_invalid_unit():
    setup_function()
    with TestClient(app) as client:
        negative = client.post("/api/pantry", json={
            "ingredient_name": "Cà chua", "quantity": -1, "unit": "kg"
        })
        assert negative.status_code == 422

        invalid_unit = client.post("/api/pantry", json={
            "ingredient_name": "Cà chua", "quantity": 2, "unit": "thùng"
        })
        assert invalid_unit.status_code == 422

def test_missing_item_returns_404():
    setup_function()
    with TestClient(app) as client:
        response = client.patch("/api/pantry/999", json={"quantity": 2})
        assert response.status_code == 404
