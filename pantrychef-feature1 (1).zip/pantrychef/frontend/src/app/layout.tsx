import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PantryChef — Quản lý nguyên liệu",
  description: "Quản lý thực phẩm sẵn có trong căn bếp của bạn.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="vi"><body>{children}</body></html>;
}
