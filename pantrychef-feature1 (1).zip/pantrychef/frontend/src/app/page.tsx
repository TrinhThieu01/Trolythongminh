"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type PantryItem = {
  id: number;
  ingredient_id: number;
  ingredient_name: string;
  category: string | null;
  quantity: string;
  unit: string;
  expiry_date: string | null;
  updated_at: string | null;
};

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const UNITS = ["g", "kg", "ml", "l", "quả", "củ", "bó", "gói", "miếng", "thìa", "chai"];

function expiryLabel(value: string | null) {
  if (!value) return "Chưa có hạn sử dụng";
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const expiry = new Date(`${value}T00:00:00`);
  const days = Math.round((expiry.getTime() - now.getTime()) / 86400000);
  if (days < 0) return `Đã qua hạn ${Math.abs(days)} ngày`;
  if (days === 0) return "Hết hạn hôm nay";
  if (days <= 3) return `Còn ${days} ngày`;
  return new Date(`${value}T00:00:00`).toLocaleDateString("vi-VN");
}

export default function Home() {
  const [items, setItems] = useState<PantryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Rau củ");
  const [quantity, setQuantity] = useState("1");
  const [unit, setUnit] = useState("quả");
  const [expiry, setExpiry] = useState("");

  const loadItems = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`${API}/api/pantry`, { cache: "no-store" });
      if (!response.ok) throw new Error("Không thể tải kho nguyên liệu.");
      setItems(await response.json());
    } catch {
      setError("Không kết nối được máy chủ. Hãy kiểm tra backend và thử tải lại.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadItems(); }, [loadItems]);

  const resetForm = () => {
    setEditingId(null); setName(""); setCategory("Rau củ"); setQuantity("1"); setUnit("quả"); setExpiry("");
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setNotice(""); setError("");
    const numericQuantity = Number(quantity);
    if (!name.trim()) { setError("Vui lòng nhập tên nguyên liệu."); return; }
    if (!Number.isFinite(numericQuantity) || numericQuantity <= 0) { setError("Số lượng phải lớn hơn 0."); return; }
    setSaving(true);
    try {
      const response = await fetch(editingId ? `${API}/api/pantry/${editingId}` : `${API}/api/pantry`, {
        method: editingId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingId
          ? { quantity: numericQuantity, unit, expiry_date: expiry || null }
          : { ingredient_name: name.trim(), category: category || null, quantity: numericQuantity, unit, expiry_date: expiry || null }),
      });
      const body = response.status === 204 ? null : await response.json().catch(() => null);
      if (!response.ok) {
        const detail = body?.detail;
        throw new Error(typeof detail === "string" ? detail : "Dữ liệu không hợp lệ. Vui lòng kiểm tra lại.");
      }
      await loadItems();
      setNotice(editingId ? "Đã cập nhật nguyên liệu." : "Đã thêm nguyên liệu vào kho.");
      resetForm();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Có lỗi xảy ra. Vui lòng thử lại.");
    } finally { setSaving(false); }
  };

  const edit = (item: PantryItem) => {
    setEditingId(item.id); setName(item.ingredient_name); setCategory(item.category || ""); setQuantity(String(item.quantity));
    setUnit(item.unit); setExpiry(item.expiry_date || ""); setError(""); setNotice("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const remove = async (item: PantryItem) => {
    if (!window.confirm(`Xóa ${item.ingredient_name} khỏi kho?`)) return;
    setError(""); setNotice("");
    try {
      const response = await fetch(`${API}/api/pantry/${item.id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Không thể xóa nguyên liệu.");
      await loadItems(); setNotice(`Đã xóa ${item.ingredient_name}.`);
      if (editingId === item.id) resetForm();
    } catch (e) { setError(e instanceof Error ? e.message : "Có lỗi xảy ra."); }
  };

  const visibleItems = items.filter(item => item.ingredient_name.toLocaleLowerCase("vi").includes(search.trim().toLocaleLowerCase("vi")));
  const nearExpiry = items.filter(item => {
    if (!item.expiry_date) return false;
    const days = (new Date(`${item.expiry_date}T00:00:00`).getTime() - new Date(new Date().toDateString()).getTime()) / 86400000;
    return days >= 0 && days <= 3;
  }).length;

  return (
    <main className="min-h-screen">
      <header className="border-b border-[var(--line)] bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <a href="/" className="flex items-center gap-3 no-underline">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--mint)] text-2xl">🥬</span>
            <span><span className="block text-xl font-bold tracking-tight">PantryChef</span><span className="block text-xs text-[var(--muted)]">Bếp gọn · Ăn ngon · Đỡ lãng phí</span></span>
          </a>
          <span className="rounded-full bg-[var(--mint)] px-3 py-2 text-sm font-semibold text-[var(--green)]">Kho nguyên liệu</span>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-5 py-8">
        <section className="mb-7 rounded-3xl bg-[#eaf2e8] p-6 sm:p-8">
          <p className="mb-2 text-sm font-bold uppercase tracking-widest text-[var(--green)]">CĂN BẾP CỦA BẠN</p>
          <h1 className="max-w-2xl text-3xl font-bold leading-tight sm:text-4xl">Bạn đang có gì trong tủ lạnh?</h1>
          <p className="mt-3 max-w-xl leading-7 text-[#58695d]">Ghi lại thực phẩm đang có, theo dõi hạn sử dụng và chủ động dùng nguyên liệu đúng lúc.</p>
          <div className="mt-6 grid grid-cols-2 gap-3 sm:max-w-lg">
            <div className="rounded-2xl bg-white/80 p-4"><p className="text-sm text-[var(--muted)]">Nguyên liệu trong kho</p><p className="mt-1 text-3xl font-bold">{items.length}</p></div>
            <div className="rounded-2xl bg-white/80 p-4"><p className="text-sm text-[var(--muted)]">Sắp đến hạn (3 ngày)</p><p className="mt-1 text-3xl font-bold">{nearExpiry}</p></div>
          </div>
        </section>

        {(error || notice) && <div role={error ? "alert" : "status"} className={`mb-5 rounded-xl border px-4 py-3 text-sm ${error ? "border-red-200 bg-red-50 text-red-800" : "border-green-200 bg-green-50 text-green-800"}`}>{error || notice}</div>}

        <div className="grid items-start gap-7 lg:grid-cols-[360px_1fr]">
          <section className="rounded-2xl border border-[var(--line)] bg-white p-5 shadow-sm">
            <div className="mb-5 flex items-center justify-between"><h2 className="text-lg font-bold">{editingId ? "Sửa nguyên liệu" : "Thêm nguyên liệu"}</h2>{editingId && <button onClick={resetForm} className="text-sm text-[var(--green)] underline">Hủy sửa</button>}</div>
            <form onSubmit={submit} className="space-y-4">
              <label className="block text-sm font-semibold">Tên nguyên liệu
                <input required maxLength={150} value={name} onChange={e => setName(e.target.value)} disabled={editingId !== null} placeholder="Ví dụ: Trứng, cà chua..." className="mt-2 w-full rounded-xl border border-[var(--line)] px-3 py-3 font-normal outline-none focus:border-[var(--green)] disabled:bg-gray-100" />
              </label>
              <label className="block text-sm font-semibold">Nhóm thực phẩm
                <select value={category} onChange={e => setCategory(e.target.value)} disabled={editingId !== null} className="mt-2 w-full rounded-xl border border-[var(--line)] bg-white px-3 py-3 font-normal outline-none focus:border-[var(--green)] disabled:bg-gray-100">
                  {["Rau củ", "Thịt cá", "Trứng & sữa", "Tinh bột", "Gia vị", "Đồ khô", "Khác"].map(x => <option key={x}>{x}</option>)}
                </select>
              </label>
              <div className="grid grid-cols-[1fr_120px] gap-3">
                <label className="block text-sm font-semibold">Số lượng
                  <input required type="number" min="0.001" step="0.001" value={quantity} onChange={e => setQuantity(e.target.value)} className="mt-2 w-full rounded-xl border border-[var(--line)] px-3 py-3 font-normal outline-none focus:border-[var(--green)]" />
                </label>
                <label className="block text-sm font-semibold">Đơn vị
                  <select value={unit} onChange={e => setUnit(e.target.value)} className="mt-2 w-full rounded-xl border border-[var(--line)] bg-white px-2 py-3 font-normal outline-none focus:border-[var(--green)]">
                    {UNITS.map(x => <option key={x}>{x}</option>)}
                  </select>
                </label>
              </div>
              <label className="block text-sm font-semibold">Hạn sử dụng <span className="font-normal text-[var(--muted)]">(không bắt buộc)</span>
                <input type="date" value={expiry} onChange={e => setExpiry(e.target.value)} className="mt-2 w-full rounded-xl border border-[var(--line)] px-3 py-3 font-normal outline-none focus:border-[var(--green)]" />
              </label>
              <button disabled={saving} type="submit" className="w-full rounded-xl bg-[var(--green)] px-4 py-3 font-bold text-white transition hover:bg-[#24543d] disabled:opacity-60">{saving ? "Đang lưu..." : editingId ? "Lưu thay đổi" : "+ Thêm vào kho"}</button>
            </form>
          </section>

          <section className="min-w-0">
            <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
              <div><h2 className="text-xl font-bold">Nguyên liệu của bạn</h2><p className="mt-1 text-sm text-[var(--muted)]">{visibleItems.length} mục trong danh sách</p></div>
              <input aria-label="Tìm nguyên liệu" value={search} onChange={e => setSearch(e.target.value)} placeholder="Tìm nguyên liệu..." className="w-full rounded-xl border border-[var(--line)] bg-white px-4 py-3 text-sm outline-none focus:border-[var(--green)] sm:max-w-xs" />
            </div>
            {loading ? <div className="rounded-2xl border border-[var(--line)] bg-white p-10 text-center text-[var(--muted)]">Đang tải kho nguyên liệu...</div>
              : visibleItems.length === 0 ? <div className="rounded-2xl border border-dashed border-[var(--line)] bg-white px-6 py-14 text-center"><div className="text-4xl">🧺</div><h3 className="mt-3 font-bold">{search ? "Không tìm thấy nguyên liệu" : "Kho bếp đang trống"}</h3><p className="mt-2 text-sm text-[var(--muted)]">{search ? "Thử một từ khóa khác nhé." : "Thêm nguyên liệu đầu tiên để bắt đầu quản lý căn bếp."}</p></div>
              : <div className="grid gap-3 sm:grid-cols-2">
                {visibleItems.map(item => <article key={item.id} className="rounded-2xl border border-[var(--line)] bg-white p-4 shadow-sm">
                  <div className="flex items-start justify-between gap-3"><div><span className="rounded-full bg-[var(--mint)] px-2.5 py-1 text-xs font-semibold text-[var(--green)]">{item.category || "Khác"}</span><h3 className="mt-3 text-lg font-bold">{item.ingredient_name}</h3></div><span className="text-2xl">🥗</span></div>
                  <p className="mt-3 text-2xl font-bold">{Number(item.quantity).toLocaleString("vi-VN", { maximumFractionDigits: 3 })} <span className="text-sm font-medium text-[var(--muted)]">{item.unit}</span></p>
                  <p className="mt-2 text-sm text-[var(--muted)]">Hạn dùng: {expiryLabel(item.expiry_date)}</p>
                  <div className="mt-4 flex gap-3 border-t border-[var(--line)] pt-3"><button onClick={() => edit(item)} className="text-sm font-semibold text-[var(--green)] hover:underline">Sửa</button><button onClick={() => void remove(item)} className="text-sm font-semibold text-red-700 hover:underline">Xóa</button></div>
                </article>)}
              </div>}
          </section>
        </div>
        <footer className="mt-10 border-t border-[var(--line)] py-5 text-center text-xs text-[var(--muted)]">PantryChef · MVP · Chức năng 1: Quản lý nguyên liệu</footer>
      </div>
    </main>
  );
}
